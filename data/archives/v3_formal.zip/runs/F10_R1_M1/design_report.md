# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为“直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速驱动左右履带”，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致，对应双功率流合成构型dual_power_stream；该构型支持continuous_radius与counterrotation_pivot两种必需转向模式，且行星参数已给定（sun=30、ring=90、planet=30，drive_input_reduction=0.942、steer_input_reduction=8.201、final_reduction=3.879），故采用双功率流而非独立HST。

候选：DP43_DM66_SP10_SM22；输入版本：4。

计算依据：采用已确认输入：working_mass=4171 kg、pump_speed=2557 r/min、travel_shaft_power_budget=30.58 kW、scenarios.1.speed=1.863 m/s、scenarios.0.speed=0.883 m/s、scenarios.2.slope=11.93°，效率与限值保持原值。工具按dual_power_stream_planetary_quasistatic_v1计算得A=0.0684178348、B=0.0235762470、ring/sun=3.0。载荷：平地作业F=3719.48 N、转场F=1985.37 N、坡地直行F=14333.90 N、缓弯F=4177.65 N且M=1259.14 N·m、原地转向F=0且M=10427.84 N·m。候选DP43_DM66_SP10_SM22（直行泵43/马达66，转向泵10/马达22）在全部5工况通过已建模检查：各工况左右纵向力均小于单侧附着能力（如坡地7166.95 N<11009.28 N，原地转向6924.20 N<13298.19 N）；泵转速2557 r/min≤3000；直行支路最高压力出现在坡地25.333 MPa≤28 MPa，转向支路最高压力出现在原地转向25.302 MPa≤28 MPa；直行马达最高转速1120.80 r/min≤3000，转向马达最高转速558.59 r/min≤3000；直行流量最大80.405 L/min≤101.155 L/min，转向流量最大13.358 L/min≤23.524 L/min；各工况泵轴功率合计最大为坡地14.481 kW≤30.58 kW。工具在81个候选中判定24个可行，并按直行泵、直行马达、转向泵、转向马达排量升序推荐DP43_DM66_SP10_SM22，该推荐不代表综合最优或真实成本最小。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着及纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价实物安装干涉、齿轮具体布置与厂家产品可采购性
- 未评价双功率流内部循环功率损失与零速保压泄漏
- 未评价作业喂入量与行走速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖
- 本方案为初步匹配，需工程人员复核后再进入详细设计

采用的完整输入见 final_design.json；独立评分未回传模型。
