# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确“直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速驱动左右履带”，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致，对应双功率流合成构型。运行器check_configuration返回configuration_id=dual_power_stream，能力覆盖continuous_radius与counterrotation_pivot，满足requirements.required_turn_modes。行星参数sun_teeth=30、ring_teeth=90、planet_teeth=30满足Nr=sun+2*planet=90，k=Nr/sun=3.0，与工具计算coefficients.ring_sun_ratio=3.0一致。

候选：DP43_DM66_SP10_SM22；输入版本：4。

计算依据：采用输入版本4：working_mass_kg=4171.0、pump_speed_rpm=2557.0、travel_shaft_power_budget_kw=30.58（已确认）、scenarios.1.speed_m_s=1.863（已确认）、scenarios.0.speed_m_s=0.883、scenarios.2.slope_deg=11.93；效率、限值、行星参数与目录均按当前case原值未改。工具calculate_loads给出A=0.0684178348327786、B=0.02357624695005881。候选DP43_DM66_SP10_SM22（直行泵43 mL/rev、直行马达66 mL/rev、转向泵10 mL/rev、转向马达22 mL/rev）在check_constraints中status=feasible_within_scope，五个工况全部通过已建模检查：平地作业直行压力6.5737 MPa、马达转速531.22 r/min、流量38.11 L/min、泵轴功率5.0427 kW；平地转场压力3.5089 MPa、转速1120.80 r/min、流量80.40 L/min、泵轴功率5.6790 kW；坡地直行压力25.3333 MPa（≤28 MPa）、转速395.86 r/min、流量28.40 L/min、泵轴功率14.4812 kW；缓弯转向直行支路压力7.3834 MPa、转向支路压力3.0552 MPa、转向马达转速248.07 r/min、两支路泵轴功率合计4.9510 kW；原地转向转向支路压力25.3019 MPa、转速558.59 r/min、流量13.36 L/min、泵轴功率6.8029 kW。各工况左右纵向力均不超过对应附着能力（如坡地直行7166.95 N≤11009.28 N，原地转向6924.20 N≤13298.19 N），泵转速2557 r/min≤3000 r/min，所有工况两支路泵轴功率之和均≤30.58 kW。工具按排量升序推荐该候选，非综合最优。

待核实事项：
- 未评价滑移、复杂土壤机理与纵横向耦合附着
- 未评价制动、动态工况、热平衡、结构强度与寿命
- 未评价内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖

采用的完整输入见 final_design.json；独立评分未回传模型。
