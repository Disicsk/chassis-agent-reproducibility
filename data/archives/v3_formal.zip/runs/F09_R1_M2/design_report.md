# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；check_configuration返回ok，具备continuous_radius与counterrotation_pivot能力，覆盖required_turn_modes。行星参数sun=30、planet=30、ring=90满足Nr=sun+2*planet=90，k=3。

候选：DP33_DM55_SP10_SM29；输入版本：3。

计算依据：输入版本3已通过validate_requirements（missing/errors/unsupported为空）。载荷计算：A=1/((1+k)*drive_input_reduction*final_reduction)=0.0602014，B=k/((1+k)*steer_input_reduction*final_reduction)=0.0216961。各工况按F=lambda*m*g*(mu*cosθ+sinθ)及左右速度v∓w*yaw/2、左右力F/2∓M/w计算。候选DP33_DM55_SP10_SM29（直行泵33/马达55，转向泵10/马达29）在全部5工况通过已建模检查：平地作业直行压力6.42MPa、流量35.23L/min、泵轴功率4.55kW；转场直行压力3.44MPa、流量71.74L/min、功率4.97kW；坡地直行压力24.53MPa、流量24.47L/min、功率12.08kW；缓弯直行压力6.97MPa/转向2.29MPa、总功率4.22kW；原地转向转向压力19.32MPa、流量17.27L/min、总功率6.71kW。全部工况左右纵向力均低于附着容量（如坡地5864.9N<9794.2N，原地6756.3N<11780.6N）；泵转速2522r/min<3000r/min；马达转速最大1200.0r/min<3000r/min；各支路流量均不超过对应泵可供流量；泵轴功率总和最大12.08kW<30.35kW预算。check_constraints返回feasible_within_scope，passes_modeled_checks=true。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未做
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉及厂家产品可采购性未确认
- 喂入量与作业速度耦合未评价

采用的完整输入见 final_design.json；独立评分未回传模型。
