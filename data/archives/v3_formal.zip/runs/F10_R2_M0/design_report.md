# 初步设计方案（待工程人员审核）

构型依据：需求为履带式联合收获机底盘，要求直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream构型及configuration_preference=common_suns_opposing_rings_carrier_outputs一致。行星参数sun=30、ring=90、planet=30，Nr=sun+2*planet=90，k=Nr/sun=3，满足齿数正整数与Nr=sun+2*planet关系。采用已确认输入：working_mass=4171 kg，g=9.81，lambda=1.204，r=0.232 m，np=2557 rpm，行走功率预算=30.58 kW，转场速度=1.863 m/s，坡地直行slope=11.93 deg，缓弯与原地转向阻力矩分别采用1045.8与8661.0 N·m。

候选：DP43_DM66_SP10_SM22；输入版本：4。

计算依据：速比：A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.942*3.879)=0.06842；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.201*3.879)=0.02358。载荷F=lambda*m*g*(mu*cosθ+sinθ)：work_flat F=3720 N；transfer_flat F=1986 N；climb F=14335 N；gentle_turn F=4178 N；pivot F=0。直行支路：Td=A*r*F/eta_g，nd=60*v/(2πrA)。work_flat Td=62.2 N·m、nd=530 rpm；transfer_flat Td=33.2 N·m、nd=1118 rpm；climb Td=239.6 N·m、nd=395 rpm；gentle_turn Td=69.8 N·m、nd=429 rpm；pivot Td=0、nd=0。转向支路：ns=60*w*yaw/(4πrB)，Ts=2*B*r*M/(w*eta_g)。gentle_turn ns=248 rpm、Ts=7.99 N·m；pivot ns=558 rpm、Ts=66.2 N·m。候选DP43_DM66_SP10_SM22：直行泵43 mL/rev，Qa=43*2557*0.92/1000=101.1 L/min；直行马达66 mL/rev，climb dp=2π*239.6/(66*0.9)=25.3 MPa<=28，n=395<=3000，Q=395*66/(1000*0.92)=28.3 L/min<=101.1；transfer Q=1118*66/(1000*0.92)=80.2 L/min<=101.1，dp=2π*33.2/(66*0.9)=3.51 MPa<=28，n=1118<=3000。转向泵10 mL/rev，Qa=10*2557*0.92/1000=23.5 L/min；转向马达22 mL/rev，pivot dp=2π*66.2/(22*0.9)=21.0 MPa<=28，n=558<=3000，Q=558*22/(1000*0.92)=13.3 L/min<=23.5；gentle_turn dp=2π*7.99/(22*0.9)=2.54 MPa<=28，n=248<=3000，Q=248*22/(1000*0.92)=5.93 L/min<=23.5。泵转速2557<=3000。功率：climb直行P=25.3*28.3/(60*0.92*0.9)=14.4 kW；transfer直行P=3.51*80.2/(60*0.92*0.9)=5.67 kW；pivot转向P=21.0*13.3/(60*0.92*0.9)=5.62 kW；两支路功率之和最大约14.4 kW<=30.58 kW。附着：climb F=14335 N<=0.55*4171*9.81*cos11.93=22050 N；gentle_turn左右纵向力=F/2±M/w=2089±694 N，绝对值最大2783 N<=0.65*4171*9.81/2=13295 N；pivot左右纵向力=0±8661/1.506=±5751 N<=13295 N。缓弯速度条件v=0.715>=abs(yaw)*w/2=0.1887*1.506/2=0.142 m/s。双功率流转向仅平地，gentle_turn与pivot slope=0满足。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本方案为初步匹配，未进行实物验证或供应商确认。
- 转向阻力矩口径按工程师确认的给定值直接作为M使用，未再乘lambda。

采用的完整输入见 final_design.json；独立评分未回传模型。
