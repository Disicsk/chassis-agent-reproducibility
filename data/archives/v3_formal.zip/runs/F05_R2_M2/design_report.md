# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比27.63；configuration_preference为independent_modular_left_right_drive，构型检查确认design_family=independent_hst，连接为发动机→左变量泵→左马达→左减速器→左履带及对应右侧支路，具备continuous_radius与counterrotation_pivot转向能力，与需求一致。

候选：P52_M53；输入版本：2。

计算依据：采用当前版本2输入：working_mass_kg=4750、load_factor=1.164、g=9.81、r=0.239 m、i=27.63、pump_speed_rpm=2632、travel_shaft_power_budget_kw=33.1、效率pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95。三工况载荷：F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))；平地作业F=3937.79 N、转场F=2256.36 N、坡地F=12941.62 N。候选P52_M53（每侧泵52 mL/rev、马达53 mL/rev）逐工况检查：平地作业dp=2.361 MPa、马达转速968.18 r/min、每侧流量55.78 L/min、泵轴功率合计5.302 kW；平地转场dp=1.353 MPa、马达转速1910.96 r/min、每侧流量110.09 L/min、泵轴功率合计5.997 kW；坡地直行dp=7.761 MPa、马达转速695.50 r/min、每侧流量40.07 L/min、泵轴功率合计12.518 kW。各工况均满足F<=adhesion_coefficient*m*g*cos(theta)、dp<=28 MPa、n<=3000 r/min、np=2632<=3000 r/min、Q<=每侧可用泵流量125.915 L/min、P<=33.1 kW。全目录6个候选检查中P52_M53、P58_M53、P58_M61可行；按目录排序规则先满足约束再取较小泵排量、较小马达排量，推荐P52_M53。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，独立HST模型仅量化直行，不量化转向负载
- 未评价滑移与复杂土壤机理、动态过程、制动与再生工况、热平衡、结构强度寿命
- 未评价实物安装干涉、采购可得性、作业喂入量与速度耦合
- 双功率流内部循环功率损失与零速泄漏不适用于本独立HST方案，未评价

采用的完整输入见 final_design.json；独立评分未回传模型。
