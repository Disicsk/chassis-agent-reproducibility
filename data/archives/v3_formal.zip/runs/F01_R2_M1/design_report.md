# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比30.39，且配置偏好为independent_modular_left_right_drive，因此采用左右独立双HST构型（design_family=independent_hst）。该构型由发动机分别驱动左、右变量泵，各自带动马达，经固定减速比减速器驱动对应履带，支持两侧独立调速与换向，满足continuous_radius与counterrotation_pivot的转向模式能力要求。

候选：P62_M58；输入版本：3。

计算依据：采用当前case输入：工作质量5177 kg，主动轮有效半径0.271 m，固定总减速比30.39，泵转速2535 r/min，行走泵轴功率预算31.92 kW，载荷系数1.177，g=9.81 m/s²；效率pump_volumetric=0.92、pump_mechanical=0.90、motor_volumetric=0.92、motor_mechanical=0.90、mechanical_reduction=0.95；限值工作压力28 MPa、马达转速3000 r/min、泵转速3000 r/min。按independent_hst稳态直行模型逐工况计算：F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))，每侧马达扭矩T=F*r/(2*i*eta_g)，马达转速n=60*i*speed/(2*pi*r)，压差dp=2*pi*T/(motor_ml_rev*eta_mm)，每侧马达流量Q=n*motor_ml_rev/(1000*eta_mv)，每侧泵可供流量Qa=pump_ml_rev*np*eta_pv/1000，两泵总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。工具对全部6个候选（P50_M58、P50_M67、P62_M58、P62_M67、P70_M58、P70_M67）完成全范围约束检查，可行候选为P62_M58、P62_M67、P70_M58、P70_M67；按目录排序规则（先满足约束，再依次最小化泵排量、马达排量）推荐P62_M58。所选P62_M58（每侧泵62 mL/rev、马达58 mL/rev）逐工况检查结果：平地作业F=4375.57 N≤附着能力27932.50 N，dp=2.472 MPa≤28 MPa，n=1137.25 r/min≤3000 r/min，np=2535 r/min≤3000 r/min，Q=71.70 L/min≤Qa=144.60 L/min，P=7.135 kW≤31.92 kW；平地转场F=2462.75 N≤33011.14 N，dp=1.391 MPa≤28 MPa，n=1860.08 r/min≤3000 r/min，Q=117.27 L/min≤144.60 L/min，P=6.568 kW≤31.92 kW；坡地直行F=14361.47 N≤27593.17 N，dp=8.113 MPa≤28 MPa，n=661.79 r/min≤3000 r/min，Q=41.72 L/min≤144.60 L/min，P=13.627 kW≤31.92 kW。全部已建模约束通过。未通过示例P50_M58、P50_M67均在平地转场工况因流量不足失败（分别需117.27、135.46 L/min，可供116.61 L/min），故不选。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，独立HST模型仅量化直行，不量化转向负载
- 未评价滑移与复杂土壤机理
- 未评价制动、动态过程、热平衡、结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入量与速度耦合
- 未支持下坡制动、倒行/再生工况，仅支持稳态、acceleration_m_s2=0
- 双功率流内部循环功率损失与零速泄漏未计入（本方案为独立HST，不适用）

采用的完整输入见 final_design.json；独立评分未回传模型。
