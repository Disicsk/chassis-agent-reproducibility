# 初步设计方案（待工程人员审核）

构型依据：需求为履带式联合收获机底盘，要求直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速输出左右履带，并需具备continuous_radius与counterrotation_pivot能力。当前design_family=dual_power_stream，check_configuration返回configuration_id=dual_power_stream，capabilities含continuous_radius与counterrotation_pivot，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致，故沿用双功率流行星合成构型。

候选：DP44_DM58_SP10_SM31；输入版本：2。

计算依据：采用当前input_version=2：travel_shaft_power_budget_kw=33.45，scenarios.1.speed_m_s=2.33，其余输入保持已确认值。行星参数sun_teeth=30、ring_teeth=90、planet_teeth=30，Nr=90，k=3；A=1/((1+k)*drive_input_reduction*final_reduction)=0.06951859761523403，B=k/((1+k)*steer_input_reduction*final_reduction)=0.02563225721826578。calculate_loads已按新版本计算各工况载荷：work_flat F=3764.72691972 N、transfer_flat F=1641.69598554 N、climb F=11579.89720190 N、gentle_turn F=3506.86891152 N且M=1196.0755 N·m、pivot F=0且M=10332.209 N·m。match_hst(scope=all)枚举目录内81个候选，check_constraints对最近一次当前版本结果检查为feasible_within_scope，推荐候选DP44_DM58_SP10_SM31。该候选为直行泵44 mL/rev、直行马达58 mL/rev、转向泵10 mL/rev、转向马达31 mL/rev。关键检查依据：坡地直行drive_pressure=27.131456168368906 MPa≤28 MPa，原地转向steering_pressure=23.520978382055915 MPa≤28 MPa；平地转场drive_motor_speed=1203.2189517726192 r/min≤3000 r/min，drive_flow=75.85510782914338 L/min≤96.70672 L/min；各工况pump_speed=2389 r/min≤3000 r/min；各工况左右纵向力均不超过对应附着容量；各工况两支路泵轴功率之和最大为坡地直行11.681155215880676 kW≤33.45 kW。因此该候选在当前需求与全部已建模约束下通过。

待核实事项：
- 未评价滑移、复杂土壤机理、横向附着/纵横向耦合与滑移。
- 未评价制动、动态、热平衡、结构强度与寿命。
- 未评价双功率流内部循环功率损失与零速保压泄漏。
- 未评价具体齿轮布置、实物安装干涉、采购可得性与厂家产品匹配。
- 未评价喂入量与作业速度耦合。
- 等效转向阻力矩的实测辨识与土壤机理预测未完成。
- 本方案为初步准静态匹配，提交状态为submitted_for_review，不替代最终独立工程评分。

采用的完整输入见 final_design.json；独立评分未回传模型。
