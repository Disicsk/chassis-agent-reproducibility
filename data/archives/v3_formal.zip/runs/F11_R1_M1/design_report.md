# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream构型（common_suns_opposing_rings_carrier_outputs）一致；该构型支持continuous_radius与counterrotation_pivot两种转向模式，满足required_turn_modes。元件均取自当前目录：直行泵34 mL/rev、直行马达60 mL/rev、转向泵9 mL/rev、转向马达35 mL/rev。

候选：DP34_DM60_SP9_SM35；输入版本：2。

计算依据：采用当前case输入（input_version=2）：travel_shaft_power_budget_kw=30.16，transfer_flat速度1.495 m/s，其余参数按已确认值。行星参数sun=30、ring=90、planet=30，k=3，A=1/((1+k)*drive_input_reduction*final_reduction)=0.0694604589391443，B=k/((1+k)*steer_input_reduction*final_reduction)=0.027935489133653436。逐工况按dual_power_stream模型计算并检查：
- work_flat：直行马达529.53 r/min、扭矩77.03 N·m、压差8.963 MPa、流量34.53 L/min（可用77.17），转向支路为0；泵轴功率6.231 kW≤30.16；单侧纵向力2002.95 N≤附着10612.95 N。
- transfer_flat（1.495 m/s）：直行马达781.48 r/min、扭矩36.80 N·m、压差4.281 MPa、流量50.97 L/min（可用77.17）；泵轴功率4.392 kW≤30.16；单侧纵向力956.73 N≤12542.58 N。
- climb：直行马达320.43 r/min、扭矩219.02 N·m、压差25.484 MPa≤28、流量20.90 L/min；泵轴功率10.720 kW≤30.16；单侧纵向力5694.87 N≤10456.50 N。
- gentle_turn：直行支路压差7.556 MPa、流量25.67 L/min；转向支路压差2.546 MPa、流量6.54 L/min（可用20.43）；泵轴功率合计4.240 kW≤30.16；左右纵向力863.44/2513.81 N≤12542.58 N。
- pivot：转向支路压差19.660 MPa≤28、转速346.31 r/min≤3000、流量13.17 L/min（可用20.43）；泵轴功率合计5.214 kW≤30.16；左右纵向力6372.19 N≤12542.58 N。
全部工况泵转速2467 r/min≤3000 r/min。工具在全部81个候选范围内检查后判定该候选满足已建模约束；该候选为按排量升序的推荐可行解，不代表综合最优。

待核实事项：
- 未评价滑移与复杂土壤机理、纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖

采用的完整输入见 final_design.json；独立评分未回传模型。
