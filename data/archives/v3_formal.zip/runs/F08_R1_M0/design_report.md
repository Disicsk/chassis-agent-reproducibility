# 初步设计方案（待工程人员审核）

构型依据：需求指定直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速输出左右履带，对应dual_power_stream构型（common_suns_opposing_rings_carrier_outputs）。行星参数自洽：Nr=sun+2*planet=30+2*30=90=ring_teeth，k=Nr/sun=3。该构型满足continuous_radius与counterrotation_pivot两种转向模式，原地转向所需履带中心距w=1.451m已给定。

候选：DP54_DM51_SP24_SM31；输入版本：2。

计算依据：采用输入：m=4000kg，λ=1.172，g=9.81，r=0.271m，w=1.451m，np=2426rpm，功率预算31.65kW，压力上限28MPa，转速上限3000rpm；ηpv=ηmv=0.92，ηpm=ηmm=0.9，ηg=0.95。行星系数：A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*1.008*3.931)=0.06310；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*7.421*3.931)=0.02571。

载荷F=λ*m*g*(μcosθ+sinθ)。
work_flat(θ=0,μ=0.0769,v=1.004): F=3537.6N；nd=60v/(2πrA)=560.7rpm；Td=A*r*F/ηg=6.366Nm；dp=2πTd/(motor*ηmm)=44.44/motor MPa；Q=nd*motor/920=0.6095*motor L/min。
transfer_flat(θ=0,μ=0.0357,v=1.999): F=1642.4N；nd=1116.5rpm；Td=2.956Nm；dp=20.63/motor MPa；Q=1.2136*motor L/min。
climb(θ=9.64°,μ=0.086,v=0.633): F=11600N；nd=353.5rpm；Td=20.87Nm；dp=145.7/motor MPa；Q=0.3842*motor L/min。
gentle_turn(v=0.816,yaw=0.1789,M=931,μ=0.0725): F=3335.5N；左速0.6862、右速0.9458；左力1026.2N、右力2309.4N；nd=455.7rpm；Td=60.02Nm；dp_d=419.0/motor MPa；Q_d=0.4953*motor L/min；ns=177.9rpm；Ts=9.411Nm；dp_s=65.70/motor MPa；Q_s=0.1934*motor L/min。
pivot(v=0,yaw=0.4179,M=9851.7,μ=0): F=0；左力-6789.6N、右力+6789.6N；nd=0，Td=0，dp_d=0，Q_d=0；ns=415.6rpm；Ts=99.56Nm；dp_s=695.1/motor MPa；Q_s=0.4517*motor L/min。

所选候选DP54_DM51_SP24_SM31（直行泵54、直行马达51、转向泵24、转向马达31）。
粘着检查：climb F=11600N≤0.55*4000*9.81*cos9.64°=21280N；pivot左右力6789.6N≤0.65*4000*9.81/2=12753N；gentle_turn左右力均≤0.65*4000*9.81/2=12753N。
压力检查：直行支路最苛刻climb dp_d=145.7/51=2.86MPa≤28；转向支路最苛刻pivot dp_s=695.1/31=22.42MPa≤28；gentle_turn dp_d=419.0/51=8.22MPa、dp_s=65.70/31=2.12MPa，均≤28。
转速检查：直行最大transfer nd=1116.5rpm≤3000；转向最大pivot ns=415.6rpm≤3000；泵转速np=2426rpm≤3000。
流量检查：Qa=pump*2426*0.92/1000=2.232*pump L/min。直行支路最苛刻Q_d=1.2136*51=61.9L/min≤2.232*54=120.5；转向支路最苛刻Q_s=0.4517*31=14.00L/min≤2.232*24=53.57；gentle_turn Q_d=0.4953*51=25.26≤120.5、Q_s=0.1934*31=6.00≤53.57。
功率检查：P=dp*Q/(60*0.92*0.9)=dp*Q/49.68。climb直行P_d=145.7*0.3842/49.68=1.127kW；pivot转向P_s=22.42*14.00/49.68=6.32kW；gentle_turn P_d=419.0*0.4953/49.68=4.177kW、P_s=65.70*0.1934/49.68=0.256kW，合计4.43kW；各工况两支路泵轴功率之和均≤31.65kW。
缓弯几何条件：v=0.816≥|yaw|*w/2=0.1789*1.451/2=0.1298，满足。
以上均为按给定公式的准静态初步匹配计算，未使用外部计算工具校核。

待核实事项：
- 目录为通用排量等级，非厂家具体型号，采购可得性未评价。
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度与寿命、实物安装干涉、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 仅支持稳态，acceleration_m_s2=0，不支持下坡制动、倒行/再生工况。
- 本方案为初步匹配，需工程人员复核并完成上述未评价项。

采用的完整输入见 final_design.json；独立评分未回传模型。
