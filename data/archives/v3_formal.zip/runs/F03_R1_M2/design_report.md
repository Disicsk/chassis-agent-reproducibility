# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比25.8；configuration_preference=independent_modular_left_right_drive。据此选择independent_hst（左右独立双HST，每侧一泵一马达，经固定减速比驱动主动轮），构型检查通过，具备continuous_radius与counterrotation_pivot能力，与required_turn_modes一致。

候选：P56_M58；输入版本：4。

计算依据：采用输入：working_mass_kg=4576、g=9.81、load_factor=1.12、drive_sprocket_effective_radius_m=0.24、fixed_reduction_ratio=25.8、pump_speed_rpm=2531、travel_shaft_power_budget_kw=31.52、效率(0.92/0.90/0.92/0.90/0.95)、压力上限28MPa、马达/泵转速上限3000r/min。载荷F=lambda*m*g*(mu*cosθ+sinθ)，每侧马达扭矩T=F*r/(2*i*eta_g)，马达转速n=60*i*v/(2*pi*r)，压差dp=2*pi*T/(V_m*eta_mm)，流量Q=n*V_m/(1000*eta_mv)，泵可供流Qa=V_p*np*eta_pv/1000，总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。三工况结果（候选P56_M58，泵56mL/rev、马达58mL/rev）：平地作业F=3992.03N、n=1120.99r/min、dp=2.353MPa、Q=70.67L/min、P=6.693kW；平地转场F=2076.46N、n=1877.56r/min、dp=1.224MPa、Q=118.37L/min、P=5.831kW；坡地直行F=12843.38N、n=641.59r/min、dp=7.569MPa、Q=40.45L/min、P=12.325kW。逐工况检查：附着力F均小于对应附着能力(24689.8/29178.9/24305.7N)通过；压差均≤28MPa通过；马达转速均≤3000r/min通过；泵转速2531≤3000r/min通过；流量均≤可供流130.397L/min通过；总轴功率最大12.325kW≤31.52kW通过。check_constraints(scope=all)判定P56_M58、P62_M58、P62_M66可行，按目录排序规则（先满足约束再取较小泵排量、较小马达排量）推荐P56_M58。

待核实事项：
- 未评价土壤转向阻力及转向工况下的压力/功率（本模型仅量化直行，转向能力仅确认结构/运动学）
- 未评价滑移与复杂土壤机理、动态过程、制动与下坡再生
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价喂入量与作业速度耦合
- 双功率流内部循环功率损失与零速泄漏未计（本方案为独立HST，不适用）

采用的完整输入见 final_design.json；独立评分未回传模型。
