# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与 dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；check_configuration 已确认该构型支持 continuous_radius 与 counterrotation_pivot，并已给出履带中心距 1.451 m，满足转向模式需求。

候选：DP36_DM58_SP9_SM31；输入版本：3。

计算依据：采用当前 input_version=3 的已确认输入：m=4000 kg，g=9.81 m/s^2，lambda=1.172，r=0.271 m，np=2426 r/min，行走功率预算 31.65 kW，压力上限 28 MPa，马达/泵转速上限 3000 r/min；行星参数 sun=30、ring=90、planet=30，drive_input_reduction=1.008，steer_input_reduction=7.421，final_reduction=3.931，效率 eta_pv=0.92、eta_pm=0.90、eta_mv=0.92、eta_mm=0.90、eta_g=0.95。calculate_loads 得 A=0.0630923、B=0.0257096、k=3.0，并给出五工况左右速度、纵向力、附着能力与支路马达转速/扭矩。match_hst(scope=all) 枚举 81 个目录候选，check_constraints 判定 30 个候选在全部工况通过，按目录排序规则推荐 DP36_DM58_SP9_SM31。该候选关键检查：坡地直行 climb 工况直行支路压力 25.13 MPa≤28 MPa、马达转速 353.5 r/min≤3000 r/min、流量 22.29 L/min≤80.35 L/min、泵轴功率合计 11.27 kW≤31.65 kW，左右纵向力 5800.23 N≤10638.62 N；原地转向 pivot 工况转向支路压力 26.29 MPa≤28 MPa、马达转速 415.5 r/min≤3000 r/min、流量 14.00 L/min≤20.09 L/min、泵轴功率合计 7.41 kW≤31.65 kW，左右纵向力 7957.40 N≤12753 N；平地作业、平地转场、缓弯转向各支路压力、转速、流量、附着与功率预算均通过。泵转速 2426 r/min≤3000 r/min。

待核实事项：
- 未评价滑移、复杂土壤机理、横向附着与纵横向耦合。
- 未评价制动、动态、热平衡、结构强度与寿命。
- 未评价实物安装干涉、采购可得性与具体齿轮布置。
- 双功率流未计内部循环功率损失与零速泄漏。
- 未评价喂入量与作业速度耦合。
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖。

采用的完整输入见 final_design.json；独立评分未回传模型。
