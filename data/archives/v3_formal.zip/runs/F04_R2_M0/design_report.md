# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比；configuration_preference=independent_modular_left_right_drive，因此采用independent_hst左右独立双HST构型。目录中pump_count_for_independent_drive=2、motor_count_for_independent_drive=2，对应每侧一泵一马达。候选编号按目录语法为P{泵排量}_M{马达排量}，选择泵排量57 mL/rev、马达排量51 mL/rev。

候选：P57_M51；输入版本：3。

计算依据：采用input_version=3及工程师已确认值：m=4170 kg，g=9.81，lambda=1.205，r=0.246 m，i=29.34，np=2485 r/min，travel_shaft_power_budget_kw=33.47，working_pressure_limit_mpa=28，motor_speed_limit_rpm=3000，pump_speed_limit_rpm=3000，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95。工况：work_flat slope=0，mu_r=0.0725，mu_a=0.55，v=0.963；transfer_flat slope=0，mu_r=0.0353，mu_a=0.65，v=1.671；climb slope=8.5°，mu_r=0.0796，mu_a=0.55，v=0.672。公共量：lambda*m*g=49293.8 N；每侧扭矩系数r/(2*i*eta_g)=0.246/(2*29.34*0.95)=0.004413 m；转速系数60*i/(2*pi*r)=1138.9 (r/min)/(m/s)；pump57可供流量Qa=57*2485*0.92/1000=130.31 L/min；功率系数2/(60*eta_pv*eta_pm)=0.040258 kW/(MPa·L/min)。逐工况：work_flat：F=49293.8*0.0725=3573.8 N，附着上限0.55*49293.8=27111.6 N满足；T=15.77 N·m；n=1096.8 r/min<3000；motor51 dp=2*pi*15.77/(51*0.90)=2.159 MPa<28；Q=1096.8*51/(1000*0.92)=60.80 L/min<=130.31；P=0.040258*2.159*60.80=5.28 kW<=33.47。transfer_flat：F=49293.8*0.0353=1740.1 N，附着上限0.65*49293.8=32041.0 N满足；T=7.68 N·m；n=1903.4 r/min<3000；dp=2*pi*7.68/(51*0.90)=1.051 MPa<28；Q=1903.4*51/920=105.51 L/min<=130.31；P=0.040258*1.051*105.51=4.46 kW<=33.47。climb：theta=8.5°=0.14835 rad，cos=0.98902，sin=0.14781；F=49293.8*(0.0796*0.98902+0.14781)=11166.4 N，附着上限0.55*49293.8*0.98902=26813.9 N满足；T=49.28 N·m；n=765.3 r/min<3000；dp=2*pi*49.28/(51*0.90)=6.746 MPa<28；Q=765.3*51/920=42.42 L/min<=130.31；P=0.040258*6.746*42.42=11.52 kW<=33.47。泵转速np=2485 r/min<=3000。对照：P45_M51在transfer_flat流量105.51>102.88 L/min不满足；P57_M58也通过但按目录排序规则先满足约束、再最小泵排量、再最小马达排量，P57_M51更符合偏好。以上为文字推导，未使用外部计算器。

待核实事项：
- 未评价滑移与复杂土壤机理
- 未评价制动、动态、热平衡
- 未评价结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入耦合
- 本模型只量化直行，未量化转向负载；required_turn_modes中的continuous_radius与counterrotation_pivot未在本独立HST直行模型中计算
- 未进行双功率流内部循环功率损失与零速泄漏评价（本方案为independent_hst）

采用的完整输入见 final_design.json；独立评分未回传模型。
