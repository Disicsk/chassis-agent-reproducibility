# 初步设计方案（待工程人员审核）

构型依据：需求明确直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速输出左右履带，与dual_power_stream构型一致；行星参数sun=30、ring=90、planet=30满足Nr=sun+2*planet=90，k=Nr/sun=3。直行与转向各一泵一马达，符合目录drive/steering各pump_count=1、motor_count=1。

候选：DP43_DM66_SP10_SM22；输入版本：3。

计算依据：采用已确认输入：m=4171kg，r=0.232m，w=1.506m，g=9.81，lambda=1.204，np=2557rpm，行走功率预算30.58kW，压力上限28MPa，马达/泵转速上限3000rpm，效率eta_pv=0.92、eta_pm=0.90、eta_mv=0.92、eta_mm=0.90、eta_g=0.95；行星drive_input_reduction=0.942、steer_input_reduction=8.201、final_reduction=3.879。A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.942*3.879)=0.06842；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.201*3.879)=0.02358。逐工况F=lambda*m*g*(mu*cosθ+sinθ)：work_flat 3721.6N；transfer_flat 1986.4N；climb 14339N；gentle_turn 4179.9N且M=1045.8Nm；pivot F=0且M=8661.0Nm。直行支路nd=60*v/(2πrA)=601.6*v，Td=A*r*F/eta_g=0.01671*F；转向支路ns=60*w*yaw/(4πrB)=1314.5*yaw，Ts=2*B*r*M/(w*eta_g)=0.007645*M。最严直行工况climb：nd=395.9rpm、Td=239.6Nm；选DM66时dp=2π*239.6/(66*0.9)=25.34MPa≤28MPa，Q=395.9*66/(1000*0.92)=28.40L/min；选DP43时Qa=43*2557*0.92/1000=101.1L/min≥28.40L/min；P=dp*Q/(60*eta_pv*eta_pm)=25.34*28.40/49.68=14.49kW≤30.58kW。转场直行nd=1120.8rpm，DM66 Q=80.4L/min≤DP43的101.1L/min，dp=2π*33.2/(66*0.9)=3.51MPa，P=3.51*80.4/49.68=5.68kW。最严转向工况pivot：ns=558.5rpm、Ts=66.2Nm；选SM22时dp=2π*66.2/(22*0.9)=21.01MPa≤28MPa，Q=558.5*22/(1000*0.92)=13.36L/min；选SP10时Qa=10*2557*0.92/1000=23.52L/min≥13.36L/min；P=21.01*13.36/49.68=5.65kW。缓弯gentle_turn：直行nd=430.1rpm、Td=69.8Nm，DM66 dp=7.38MPa、Q=30.85L/min、P=4.58kW；转向ns=248.1rpm、Ts=8.0Nm，SM22 dp=2.54MPa、Q=5.93L/min、P=0.30kW；合计4.88kW≤30.58kW。附着检查：climb左右纵向力F/2=7169.5N≤0.55*4171*9.81*cos11.93°/2=11010N；gentle_turn最大单侧F/2+M/w=2090+694.4=2784.4N≤0.65*4171*9.81/2=13298N；pivot单侧M/w=5751N≤13298N。转速检查：直行马达最大1120.8rpm≤3000rpm，转向马达最大558.5rpm≤3000rpm，泵转速2557rpm≤3000rpm。流量检查：各工况直行Q≤DP43的Qa、转向Q≤SP10的Qa。功率检查：各工况两支路泵轴功率之和最大约14.49kW≤30.58kW。候选DP43_DM66_SP10_SM22在目录内且满足上述适用约束。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本方案为稳态准静态初步匹配，不支持下坡制动、倒行/再生工况。
- 转向负载仅按给定等效阻力矩校核，未量化复杂转向动力学。

采用的完整输入见 final_design.json；独立评分未回传模型。
