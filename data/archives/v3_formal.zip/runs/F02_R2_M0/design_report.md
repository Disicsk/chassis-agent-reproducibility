# 初步设计方案（待工程人员审核）

构型依据：文字需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比；configuration_preference=independent_modular_left_right_drive，故采用 independent_hst 构型，使用 fixed_reduction_ratio=26.86，左右各一泵一马达，共2泵2马达。该构型可独立控制两侧速度与换向，原理上支持 continuous_radius 与 counterrotation_pivot 所需左右差速/反向。

候选：P60_M55；输入版本：3。

计算依据：输入：m=4732kg，lambda=1.125，g=9.81，r=0.267m，i=26.86，np=2457rpm，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95，压力上限28MPa，马达转速上限3000rpm，泵转速上限3000rpm，行走泵轴功率预算29.01kW。

逐工况共同载荷 F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))：
work_flat：theta=0，F=1.125*4732*9.81*0.0842=4397.2N；附着力上限=0.55*4732*9.81=25531.5N，F<=上限。
transfer_flat：theta=0，F=1.125*4732*9.81*0.0421=2198.6N；附着力上限=0.65*4732*9.81=30173.6N，F<=上限。
climb：theta=9.01deg=0.15725rad，cos=0.98766，sin=0.15660，F=1.125*4732*9.81*(0.0841*0.98766+0.15660)=12515.9N；附着力上限=0.55*4732*9.81*0.98766=25216.4N，F<=上限。

马达转速 n=60*i*speed/(2*pi*r)，分母2*pi*0.267=1.677：
work_flat：n=60*26.86*0.879/1.677=844.7rpm<=3000。
transfer_flat：n=60*26.86*1.981/1.677=1903.7rpm<=3000。
climb：n=60*26.86*0.612/1.677=588.1rpm<=3000。
泵转速 np=2457rpm<=3000。

每侧马达扭矩 T=F*r/(2*i*eta_g)=F*0.267/(2*26.86*0.95)=F*0.005232：
work_flat T=23.00Nm；transfer_flat T=11.50Nm；climb T=65.48Nm。

候选 P60_M55（马达55mL/rev）：
dp=2*pi*T/(motor_ml*eta_mm)=6.98132*T/55：work_flat=2.92MPa，transfer_flat=1.46MPa，climb=8.31MPa，均<=28MPa。
Q=n*motor_ml/(1000*eta_mv)=n*55/920：work_flat=50.49L/min，transfer_flat=113.8L/min，climb=35.16L/min。
泵60供流 Qa=60*2457*0.92/1000=135.63L/min，各工况Q<=Qa。
P=2*dp*Q/(60*eta_pv*eta_pm)=dp*Q/24.84：work_flat=5.94kW，transfer_flat=6.69kW，climb=11.76kW，均<=29.01kW。

目录筛选：泵48供流Qa=108.50L/min，transfer_flat工况马达55需113.8L/min，Q>Qa，泵48被过滤；泵60、67满足流量。马达55与64在压力、转速、功率上均满足，按ranking_rule先最小泵排量再最小马达排量，选泵60、马达55，即P60_M55。

待核实事项：
- 独立HST计算模型只量化直行，不量化转向负载；required_turn_modes中的continuous_radius与counterrotation_pivot仅能从构型上说明左右独立泵马达可实现差速/反向，转向阻力矩、原地转向能力、转向压力/流量/功率未在本模型检查。
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 仅支持稳态，acceleration_m_s2=0；不支持下坡制动、倒行/再生工况。
- 效率、功率预算、元件目录均按给定值保留，未做修改。

采用的完整输入见 final_design.json；独立评分未回传模型。
