# 初步设计方案（待工程人员审核）

构型依据：采用双功率流（dual_power_stream）行星合成构型：直行马达同向驱动两太阳轮，转向马达反向驱动两齿圈，行星架经末级减速输出左右履带，与工程师给定的 configuration_preference=common_suns_opposing_rings_carrier_outputs 及所需转向能力 continuous_radius、counterrotation_pivot 一致；行星参数 sun=30、ring=90、planet=30 满足 Nr=sun+2*planet=90，k=Nr/sun=3。

候选：DP44_DM58_SP10_SM31；输入版本：2。

计算依据：输入采用当前版本2：行走泵轴功率预算33.45 kW、平地转场速度2.33 m/s，其余参数保持题面给定值。载荷按 dual_power_stream 模型计算：A=1/((1+k)*drive_input_reduction*final_reduction)=0.0695186，B=k/((1+k)*steer_input_reduction*final_reduction)=0.0256323。各工况直行支路 nd=60*v/(2*pi*r*A)、Td=A*r*F/eta_g，转向支路 ns=60*w*yaw/(4*pi*r*B)、Ts=2*B*r*M/(w*eta_g)；dp=2*pi*abs(T)/(motor_ml_rev*eta_mm)，Q=abs(n)*motor_ml_rev/(1000*eta_mv)，Qa=pump_ml_rev*np*eta_pv/1000，P=dp*Q/(60*eta_pv*eta_pm)。候选 DP44_DM58_SP10_SM31（直行泵44 mL/rev、直行马达58 mL/rev、转向泵10 mL/rev、转向马达31 mL/rev）在全部5个工况通过已建模约束：平地作业直行压力8.82 MPa、转场直行压力3.85 MPa、坡地直行压力27.13 MPa（≤28 MPa，为最紧工况）、缓弯转向直行压力8.22 MPa/转向压力2.72 MPa、原地转向转向压力23.52 MPa（≤28 MPa）；各工况马达转速最高1203.2 r/min（≤3000）、泵转速2389 r/min（≤3000）、流量均不超过对应泵可供流量、左右纵向力均不超过附着上限、泵轴功率合计最大11.68 kW（≤33.45 kW）。全目录81个候选枚举后，18个候选可行，本候选为按排量升序推荐项。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着/纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩为给定值，未经实测辨识

采用的完整输入见 final_design.json；独立评分未回传模型。
