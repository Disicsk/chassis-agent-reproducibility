# 初步设计方案（待工程人员审核）

构型依据：工程师要求直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，对应构型为dual_power_stream（common_suns_opposing_rings_carrier_outputs）。该构型检查已通过，具备continuous_radius与counterrotation_pivot能力，满足required_turn_modes。行星参数sun=30、ring=90、planet=30满足Nr=sun+2*planet=90，k=Nr/sun=3。

候选：DP34_DM60_SP9_SM35；输入版本：2。

计算依据：采用最新确认输入：travel_shaft_power_budget_kw=30.16、scenarios.1.speed_m_s=1.495，其余参数保持原值。载荷系数A=1/((1+k)*drive_input_reduction*final_reduction)=0.0694604589，B=k/((1+k)*steer_input_reduction*final_reduction)=0.0279354891。各工况按模型计算直行/转向支路马达转速、扭矩、压差、流量与泵轴功率。候选DP34_DM60_SP9_SM35：直行泵34 mL/rev、直行马达60 mL/rev、转向泵9 mL/rev、转向马达35 mL/rev。关键检查（全部通过）：平地作业直行压差8.963 MPa、马达转速529.53 r/min、流量34.53 L/min、泵轴功率6.23 kW；平地转场（1.495 m/s）直行压差4.281 MPa、马达转速781.48 r/min、流量50.97 L/min、泵轴功率4.39 kW；坡地直行直行压差25.484 MPa（<28）、马达转速320.43 r/min、泵轴功率10.72 kW；缓弯转向直行压差7.556 MPa、转向压差2.546 MPa、转向马达转速171.97 r/min、总泵轴功率4.24 kW；原地转向转向压差19.660 MPa（<28）、转向马达转速346.31 r/min、流量13.17 L/min、总泵轴功率5.21 kW。各工况左右纵向力均不超过附着能力（如坡地5694.87 N<10456.50 N，原地转向6372.19 N<12542.58 N），泵转速2467 r/min<3000 r/min，各支路流量均不超过对应泵可供流量，各工况泵轴功率之和均不超过30.16 kW。约束检查范围scope=all，覆盖全部81个候选，feasible_ids共54项，本候选为字典序推荐项。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未评价
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉与厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价

采用的完整输入见 final_design.json；独立评分未回传模型。
