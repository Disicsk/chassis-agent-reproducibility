# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比，configuration_preference=independent_modular_left_right_drive，因此采用independent_hst构型：左右各一泵一马达，每侧经固定总减速比i=27.63驱动主动轮，可独立控制两侧速度与换向。目录规定独立驱动泵数2、马达数2，与构型一致。

候选：P52_M53；输入版本：2。

计算依据：采用当前case v2输入：m=4750 kg，lambda=1.164，g=9.81 m/s^2，r=0.239 m，i=27.63，np=2632 r/min，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95；压力上限28 MPa，马达转速上限3000 r/min，泵转速上限3000 r/min；行走泵轴功率预算33.1 kW；目录泵排量[42,52,58] mL/rev，马达排量[53,61] mL/rev。候选P52_M53：泵52 mL/rev，马达53 mL/rev。每侧泵供流Qa=52*2632*0.92/1000=125.91488 L/min。逐工况按theta=slope*pi/180，F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))，T=F*r/(2*i*eta_g)，n=60*i*speed/(2*pi*r)，dp=2*pi*T/(motor_ml_rev*eta_mm)，Q=n*motor_ml_rev/(1000*eta_mv)，P=2*dp*Q/(60*eta_pv*eta_pm)计算。work_flat：F=3937.79 N，T=17.927 Nm，dp=2.361 MPa<=28，n=968.18 r/min<=3000，Q=55.775 L/min<=125.915，P=5.302 kW<=33.1，附着力3937.79<=0.55*4750*9.81=25628.63 N。transfer_flat（speed=1.731 m/s）：F=2256.36 N，T=10.272 Nm，dp=1.353 MPa<=28，n=1910.85 r/min<=3000，Q=110.082 L/min<=125.915，P=5.996 kW<=33.1，附着力2256.36<=0.65*4750*9.81=30288.38 N。climb：theta=9.4deg，F=12941.62 N，T=58.918 Nm，dp=7.761 MPa<=28，n=695.50 r/min<=3000，Q=40.067 L/min<=125.915，P=12.517 kW<=33.1，附着力12941.62<=0.55*4750*9.81*cos(9.4deg)=25284.49 N。泵转速2632 r/min<=3000。目录筛选：P42_M53在transfer_flat需Q=110.082 L/min>Qa(42)=101.700 L/min，流量不通过；P42_M61需Q=126.70 L/min>101.700，不通过；P52_M61在transfer_flat需Q=126.70 L/min>125.915，不通过。因此按目录排序规则（先过滤已建模约束，再最小泵排量、再最小马达排量），P52_M53为可行候选。

待核实事项：
- 本独立HST模型只量化直行，未量化continuous_radius与counterrotation_pivot转向负载；转向能力需另行校核。
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 未进行下坡制动、倒行/再生工况校核；模型仅支持稳态、acceleration_m_s2=0。
- 效率、功率预算、元件目录均按给定值采用，未做实物效率标定或成本优化。

采用的完整输入见 final_design.json；独立评分未回传模型。
