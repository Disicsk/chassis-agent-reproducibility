# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自变量泵、马达与减速器驱动并保留既有固定总减速比26.37，configuration_preference为independent_modular_left_right_drive，故采用independent_hst（左右独立双HST，每侧一泵一马达，固定总减速比i=26.37）。该构型经check_configuration确认具备continuous_radius与counterrotation_pivot转向能力，与required_turn_modes一致。

候选：P60_M51；输入版本：2。

计算依据：采用当前版本输入：working_mass=3806 kg，lambda=1.16，g=9.81，r=0.269 m，i=26.37，np=2529 r/min，行走泵轴功率预算34.01 kW，效率eta_pv=0.92、eta_pm=0.90、eta_mv=0.92、eta_mm=0.90、eta_g=0.95，压力上限28 MPa，马达/泵转速上限3000 r/min。三工况载荷：F=lambda*m*g*(mu*cosθ+sinθ)，每侧马达扭矩T=F*r/(2*i*eta_g)，转速n=60*i*v/(2*pi*r)，压差dp=2*pi*T/(motor_ml*eta_mm)，流量Q=n*motor_ml/(1000*eta_mv)，泵可供流Qa=pump_ml*np*eta_pv/1000，总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。对目录内6个候选（泵49/60/68，马达51/58）执行match_hst(all)与check_constraints：P49_M51、P49_M58在平地转场工况流量不足（117.85、134.03 L/min > 114.01 L/min）被排除；P60_M51、P60_M58、P68_M51、P68_M58均通过全部已建模约束。按目录排序规则（先满足约束，再最小泵排量、再最小马达排量）推荐P60_M51。P60_M51逐工况检查：平地作业F=3651.10 N≤附着20535.27 N，dp=2.683 MPa≤28，n=849.06≤3000，Q=47.07≤139.60 L/min，P=5.084 kW≤34.01；平地转场F=1884.02 N≤24268.96 N，dp=1.385 MPa≤28，n=2125.92≤3000，Q=117.85≤139.60 L/min，P=6.569 kW≤34.01；坡地直行F=11151.64 N≤20228.26 N，dp=8.196 MPa≤28，n=502.69≤3000，Q=27.87≤139.60 L/min，P=9.195 kW≤34.01。泵转速2529≤3000。全部已建模约束通过。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行，转向负载未量化）
- 未评价滑移与复杂土壤机理、动态过程、制动与下坡再生
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行驶速度耦合
- 双功率流内部循环功率损失与零速泄漏未计（本方案为独立HST，不适用）

采用的完整输入见 final_design.json；独立评分未回传模型。
