# 初步设计方案（待工程人员审核）

构型依据：采用双功率流构型 dual_power_stream，符合 requirements.configuration_preference=common_suns_opposing_rings_carrier_outputs：直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速驱动左右履带。行星参数已给定：sun_teeth=30、ring_teeth=90、planet_teeth=30，故 Nr=sun+2*planet=90，k=Nr/sun=3。该构型可覆盖 required_turn_modes 中的 continuous_radius 与 counterrotation_pivot，并利用给定 track_center_distance_m=1.42 m 进行原地转向计算。

候选：DP51_DM74_SP10_SM31；输入版本：2。

计算依据：采用当前 input_version=2 的输入：m=3666 kg，lambda=1.195，g=9.81 m/s2，r=0.266 m，w=1.42 m，np=2389 r/min，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95，压力上限28 MPa，马达/泵转速上限3000 r/min，行走功率预算33.45 kW。行星：drive_input_reduction=0.96，steer_input_reduction=7.811，final_reduction=3.746。A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.96*3.746)=0.069518；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*7.811*3.746)=0.025632。所选元件：驱动泵51 mL/rev、驱动马达74 mL/rev、转向泵10 mL/rev、转向马达31 mL/rev，均在 illustrative_catalog 内。驱动泵供流 Qa_d=51*2389*0.92/1000=112.10 L/min；转向泵供流 Qa_s=10*2389*0.92/1000=21.98 L/min；泵转速2389 r/min<3000 r/min。逐工况检查：work_flat：F=3764.73 N，nd=485.42 r/min，Td=73.24 N·m，dp_d=6.91 MPa，Q_d=39.05 L/min<112.10，P=5.43 kW<33.45；左右纵向力1882.36 N<9889.95 N。transfer_flat：v=2.33 m/s，F=1641.70 N，nd=1203.43 r/min<3000，Td=31.94 N·m，dp_d=3.01 MPa，Q_d=96.80 L/min<112.10，P=5.86 kW<33.45；左右纵向力820.85 N<11688.12 N。climb：theta=11.53°，F=11579.9 N，nd=339.28 r/min，Td=225.31 N·m，dp_d=21.25 MPa<28，Q_d=27.29 L/min<112.10，P=11.67 kW<33.45；左右纵向力5789.95 N<9690.37 N。gentle_turn：v=0.899 m/s，yaw=0.2 rad/s，M=1000.9 N·m，F=3507.0 N；左纵向力1048.64 N、右纵向力2458.36 N，均<11688.12 N；直行支路nd=464.25 r/min，Td=68.24 N·m，dp_d=6.44 MPa，Q_d=37.34 L/min<112.10，P_d=4.84 kW；转向支路ns=198.88 r/min<3000，Ts=10.12 N·m，dp_s=2.28 MPa<28，Q_s=6.70 L/min<21.98，P_s=0.31 kW；两支路泵轴功率和5.15 kW<33.45。pivot：v=0，yaw=0.4173 rad/s，M=8646.2 N·m，F=0；左右纵向力绝对值6088.87 N<11688.12 N；直行支路0；转向支路ns=414.96 r/min<3000，Ts=87.40 N·m，dp_s=19.69 MPa<28，Q_s=13.98 L/min<21.98，P_s=5.54 kW<33.45。原既有候选DP34_DM58_SP10_SM31在更新后的 transfer_flat 速度2.33 m/s下驱动流量约75.86 L/min>Qa_d=74.73 L/min，不满足流量约束，因此本次改为DP51_DM74_SP10_SM31。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流模型未计内部循环功率损失与零速泄漏。
- 本方案为按给定公式和目录完成的准静态初步匹配，不能替代最终工程审核与实物验证。

采用的完整输入见 final_design.json；独立评分未回传模型。
