# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比27.63；configuration_preference=independent_modular_left_right_drive，design_family=independent_hst，与左右独立双HST构型一致。该构型支持continuous_radius与counterrotation_pivot的转向能力确认，满足所需转向模式的结构/运动学能力。

候选：P52_M53；输入版本：2。

计算依据：采用最新确认输入：travel_shaft_power_budget_kw=33.1，scenarios.1.speed_m_s=1.731，其余参数保持当前case值。按independent_hst模型逐工况计算：F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))；每侧马达扭矩T=F*r/(2*i*eta_g)；马达转速n=60*i*speed/(2*pi*r)；压差dp=2*pi*T/(motor_ml_rev*eta_mm)；每侧马达流量Q=n*motor_ml_rev/(1000*eta_mv)；每侧泵供流Qa=pump_ml_rev*np*eta_pv/1000；两泵总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。对目录内6个候选枚举并检查约束后，可行候选为P52_M53、P58_M53、P58_M61；按目录排序规则先最小泵排量再最小马达排量，推荐P52_M53。P52_M53检查结果：平地作业F=3937.79N<=附着力25628.63N，dp=2.361MPa<=28MPa，n=968.18r/min<=3000r/min，np=2632r/min<=3000r/min，Q=55.78L/min<=Qa=125.91L/min，P=5.302kW<=33.1kW；平地转场F=2256.36N<=30288.38N，dp=1.353MPa<=28MPa，n=1910.96r/min<=3000r/min，np=2632r/min<=3000r/min，Q=110.09L/min<=125.91L/min，P=5.997kW<=33.1kW；坡地直行F=12941.62N<=25284.49N，dp=7.761MPa<=28MPa，n=695.50r/min<=3000r/min，np=2632r/min<=3000r/min，Q=40.07L/min<=125.91L/min，P=12.518kW<=33.1kW。P42_M53与P42_M61在平地转场流量约束不通过，故不采用。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，本独立HST模型只量化直行，不量化转向负载
- 未评价滑移与复杂土壤机理、动态过程、制动/下坡制动/倒行再生工况
- 未评价热平衡、结构强度寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行驶速度耦合
- 双功率流内部循环功率损失与零速泄漏不适用于本独立HST方案，未作评价

采用的完整输入见 final_design.json；独立评分未回传模型。
