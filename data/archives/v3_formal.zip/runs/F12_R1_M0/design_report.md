# 初步设计方案（待工程人员审核）

构型依据：需求为履带式联合收获机底盘，指定采用双功率流：直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速驱动左右履带，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致。行星参数已给定sun=30、ring=90、planet=30，满足Nr=sun+2*planet=90；drive_input_reduction=0.96、steer_input_reduction=7.811、final_reduction=3.746。元件从当前目录选择：直行泵51 mL/rev、直行马达74 mL/rev、转向泵10 mL/rev、转向马达38 mL/rev。

候选：DP51_DM74_SP10_SM38；输入版本：2。

计算依据：采用当前input_version=2：travel_shaft_power_budget_kw=33.45，transfer_flat speed=2.33 m/s；其余按当前case。行星系数：k=Nr/sun=90/30=3；A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.96*3.746)=0.069518；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*7.811*3.746)=0.025632。直行支路：Td=A*r*F/eta_g，nd=60*v/(2*pi*r*A)，dp=2*pi*abs(Td)/(DM*eta_mm)，Q=abs(nd)*DM/(1000*eta_mv)，Qa=DP*np*eta_pv/1000=51*2389*0.92/1000=112.09 L/min，P=dp*Q/(60*eta_pv*eta_pm)。转向支路：ns=60*w*yaw/(4*pi*r*B)，Ts=2*B*r*M/(w*eta_g)，dp=2*pi*abs(Ts)/(SM*eta_mm)，Q=abs(ns)*SM/(1000*eta_mv)，Qa=SP*np*eta_pv/1000=10*2389*0.92/1000=21.98 L/min，P=dp*Q/(60*eta_pv*eta_pm)。逐工况结果：work_flat F=3764.7 N，Td=73.27 N·m，nd=485.4 rpm，dp=6.91 MPa，Q=39.05 L/min，P=5.43 kW；transfer_flat F=1641.7 N，Td=31.95 N·m，nd=1203.0 rpm，dp=3.01 MPa，Q=96.76 L/min，P=5.86 kW；climb F=11579.9 N，Td=225.4 N·m，nd=339.3 rpm，dp=21.26 MPa，Q=27.29 L/min，P=11.68 kW；gentle_turn 直行F=3507.0 N，Td=68.25 N·m，nd=464.2 rpm，dp=6.44 MPa，Q=37.35 L/min，P=4.84 kW，转向ns=198.9 rpm，Ts=10.09 N·m，dp=1.85 MPa，Q=8.21 L/min，P=0.31 kW，合计约5.15 kW；pivot 直行支路为0，转向ns=415.0 rpm，Ts=87.18 N·m，dp=16.02 MPa，Q=17.14 L/min，P=5.53 kW。约束检查：所有工况直行/转向dp均<=28 MPa；abs(n)均<=3000 rpm；泵转速2389<=3000 rpm；直行Q<=112.09 L/min、转向Q<=21.98 L/min；两支路泵轴功率之和最大约11.68 kW（climb）<=33.45 kW。附着力：各工况左右纵向力绝对值均不超过adhesion*m*g*cos(theta)/2，例如climb单侧约5790 N<9690 N，pivot单侧约7276 N<11688 N。

待核实事项：
- 未评价滑移与复杂土壤机理
- 未评价制动、动态、热平衡
- 未评价结构强度寿命、实物安装干涉、采购可得性
- 未评价作业喂入耦合
- 双功率流未计内部循环功率损失与零速泄漏
- 本方案为准静态初步匹配，不能宣称上述未评价指标已验证

采用的完整输入见 final_design.json；独立评分未回传模型。
