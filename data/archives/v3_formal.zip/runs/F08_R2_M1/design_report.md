# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；工具check_configuration返回configuration_id=dual_power_stream，能力覆盖continuous_radius与counterrotation_pivot，满足所需转向模式。

候选：DP36_DM58_SP9_SM31；输入版本：4。

计算依据：采用dual_power_stream_planetary_quasistatic_v1模型，行星参数sun_teeth=30、ring_teeth=90、planet_teeth=30，k=Nr/Ns=3，A=1/((1+k)*drive_input_reduction*final_reduction)=0.0630923，B=k/((1+k)*steer_input_reduction*final_reduction)=0.0257096。载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))逐工况计算：work_flat F=3536.58 N、transfer_flat F=1641.82 N、climb F=11600.46 N、gentle_turn F=3334.22 N且M=1091.13 N·m、pivot F=0且M=11546.19 N·m。候选DP36_DM58_SP9_SM31（直行泵36 mL/rev、直行马达58 mL/rev、转向泵9 mL/rev、转向马达31 mL/rev）在全部5个工况通过已建模检查：左右纵向力均不超过附着能力（如climb 5800.23 N≤10638.62 N，pivot 7957.40 N≤12753 N）；直行支路最高压力出现在climb为25.13 MPa≤28 MPa，最高转速出现在transfer_flat为1116.45 r/min≤3000 r/min，最大流量70.38 L/min≤80.35 L/min；转向支路最高压力出现在pivot为26.29 MPa≤28 MPa，最高转速415.54 r/min≤3000 r/min，最大流量14.00 L/min≤20.09 L/min；泵转速2426 r/min≤3000 r/min；各工况两支路泵轴功率之和最大为climb的11.27 kW≤31.65 kW。工具check_constraints返回status=feasible_within_scope、passes_modeled_checks=true、failures为空。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着与纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 双功率流未计内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识未做，仅按给定值作准静态演示
- 候选按排量字典序推荐，不代表综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
