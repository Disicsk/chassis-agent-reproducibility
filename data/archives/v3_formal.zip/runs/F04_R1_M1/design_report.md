# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比29.34，故采用左右独立双HST构型（independent_hst）。该构型由发动机分别驱动左、右变量泵，经左、右马达及各自减速器驱动对应履带，具备continuous_radius与counterrotation_pivot所需的两侧独立调速与换向能力。

候选：P57_M51；输入版本：4。

计算依据：采用已确认输入：working_mass_kg=4170.0，pump_speed_rpm=2485.0，drive_sprocket_effective_radius_m=0.246，fixed_reduction_ratio=29.34，load_factor=1.205，g=9.81，travel_shaft_power_budget_kw=33.47；效率pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95；限值working_pressure_limit_mpa=28、motor_speed_limit_rpm=3000、pump_speed_limit_rpm=3000。三工况为work_flat(slope=0,res=0.0725,adh=0.55,v=0.963)、transfer_flat(slope=0,res=0.0353,adh=0.65,v=1.671)、climb(slope=8.5,res=0.0796,adh=0.55,v=0.672)。按independent_hst模型：F=lambda*m*g*(res*cosθ+sinθ)，每侧马达扭矩T=F*r/(2*i*eta_g)，马达转速n=60*i*v/(2*pi*r)，压差dp=2*pi*T/(motor_ml_rev*eta_mm)，每侧马达流量Q=n*motor_ml_rev/(1000*eta_mv)，每侧泵可供流量Qa=pump_ml_rev*np*eta_pv/1000，两泵总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。工具对全部6个候选（P45_M51、P45_M58、P57_M51、P57_M58、P64_M51、P64_M58）逐工况检查，可行候选为P57_M51、P57_M58、P64_M51、P64_M58；按目录排序规则（先满足约束，再最小泵排量、再最小马达排量）推荐P57_M51。该候选三工况检查结果：work_flat F=3573.80N≤22499.24N，dp=2.159MPa≤28MPa，n=1096.79r/min≤3000r/min，np=2485r/min≤3000r/min，Q=60.80L/min≤130.31L/min，P=5.284kW≤33.47kW；transfer_flat F=1740.07N≤26590.01N，dp=1.051MPa≤28MPa，n=1903.15r/min≤3000r/min，np=2485r/min≤3000r/min，Q=105.50L/min≤130.31L/min，P=4.464kW≤33.47kW；climb F=11166.77N≤22252.10N，dp=6.746MPa≤28MPa，n=765.36r/min≤3000r/min，np=2485r/min≤3000r/min，Q=42.43L/min≤130.31L/min，P=11.522kW≤33.47kW。所有已建模约束均通过。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，本模型仅量化直行，不量化转向负载
- 未评价滑移与复杂土壤机理
- 未评价制动、动态过程、热平衡、结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价喂入量与作业速度耦合
- 双功率流内部循环功率损失与零速泄漏不适用本构型但未评价
- 候选排序为按目录规则的推荐，非综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
