# 初步设计方案（待工程人员审核）

构型依据：需求明确直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致，故采用dual_power_stream双功率流构型。该构型经check_configuration确认支持continuous_radius与counterrotation_pivot两种必需转向模式，并具备原地转向所需的履带中心距输入(track_center_distance_m=1.506)。行星参数sun_teeth=30、ring_teeth=90、planet_teeth=30满足Nr=sun+2*planet=90=ring，k=Nr/sun=3；由drive_input_reduction=0.942、steer_input_reduction=8.201、final_reduction=3.879算得A=1/((1+k)*0.942*3.879)=0.068418、B=k/((1+k)*8.201*3.879)=0.023576。

候选：DP43_DM66_SP10_SM22；输入版本：3。

计算依据：采用输入版本3：working_mass_kg=4171、pump_speed_rpm=2557、travel_shaft_power_budget_kw=30.58（工程师已确认）、scenarios.1.speed_m_s=1.863（工程师已确认）、scenarios.0.speed_m_s=0.883、scenarios.2.slope_deg=11.93，其余效率与限值按给定值不变。载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))逐工况计算，双功率流按左/右速度v∓w*yaw/2、左/右纵向力F/2∓M/w、直行马达nd=60*v/(2*pi*r*A)、Td=A*r*F/eta_g、转向马达ns=60*w*yaw/(4*pi*r*B)、Ts=2*B*r*M/(w*eta_g)计算，各支路dp=2*pi*abs(T)/(motor_ml_rev*eta_mm)、Q=abs(n)*motor_ml_rev/(1000*eta_mv)、Qa=pump_ml_rev*np*eta_pv/1000、P=dp*Q/(60*eta_pv*eta_pm)。所选DP43_DM66_SP10_SM22（直行泵43 mL/rev、直行马达66 mL/rev、转向泵10 mL/rev、转向马达22 mL/rev）在全部5个工况下通过已建模检查：坡地直行climb为最严苛工况，直行支路压力25.333 MPa≤28 MPa、马达转速395.86 r/min≤3000、流量28.40 L/min≤101.15 L/min、泵轴功率合计14.481 kW≤30.58 kW；原地转向pivot转向支路压力25.302 MPa≤28 MPa、转速558.59 r/min≤3000、流量13.36 L/min≤23.52 L/min、泵轴功率合计6.803 kW≤30.58 kW；平地作业、平地转场、缓弯转向各支路压力、转速、流量与功率均在上限内；各工况左右纵向力绝对值均不超过adhesion_coefficient*m*g*cos(theta)/2（如climb为7166.95 N≤11009.28 N，pivot为6924.20 N≤13298.19 N）；泵转速2557 r/min≤3000 r/min。check_constraints在scope=all下枚举81项候选，feasible_ids共24项，本候选为按排量升序推荐项，非综合最优。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着/纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 双功率流未计内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未做
- 本方案为初步匹配，需工程人员复核后进入详细设计

采用的完整输入见 final_design.json；独立评分未回传模型。
