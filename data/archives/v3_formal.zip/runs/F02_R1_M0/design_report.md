# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，保留既有固定总减速比，configuration_preference=independent_modular_left_right_drive，故采用independent_hst：每侧一泵一马达，共2泵2马达，固定总减速比i=26.86。该构型支持左右独立控制速度与换向，符合continuous_radius与counterrotation_pivot转向需求。目录泵排量[48,60,67]mL/rev、马达排量[55,64]mL/rev，各选2件。

候选：P60_M55；输入版本：2。

计算依据：采用输入：m=4732kg，g=9.81，lambda=1.125，r=0.267m，i=26.86，np=2457r/min，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95，压力上限28MPa，马达转速上限3000r/min，泵转速上限3000r/min，行走泵轴功率预算29.01kW<=发动机118kW。工况：work_flat v=0.879,slope=0,mu_r=0.0842,mu_a=0.55；transfer_flat v=1.981,slope=0,mu_r=0.0421,mu_a=0.65；climb v=0.612,slope=9.01deg,mu_r=0.0841,mu_a=0.55。载荷F=lambda*m*g*(mu_r*cosθ+sinθ)：work_flat约4397N，transfer_flat约2198N，climb约12516N。附着检查F<=mu_a*m*g*cosθ：work_flat 4397<=25531N，transfer 2198<=30174N，climb 12516<=25216N，均通过。每侧马达扭矩T=F*r/(2*i*eta_g)=F*0.005232：work_flat约23.0N·m，transfer约11.5N·m，climb约65.5N·m。马达转速n=60*i*v/(2*pi*r)=960.5*v：work_flat约844r/min，transfer约1903r/min，climb约588r/min，均<=3000r/min。压差dp=2*pi*T/(V_m*eta_mm)=6.9813*T/V_m；最恶劣climb，V_m=55时dp约8.31MPa，V_m=64时约7.14MPa，均<=28MPa。流量Q=n*V_m/(1000*eta_mv)=n*V_m/920：transfer为流量最恶劣工况，V_m=55时Q约113.8L/min，V_m=64时约132.4L/min；climb V_m=55约35.2L/min。泵供流Qa=V_p*np*eta_pv/1000=2.2604*V_p：V_p=48时108.5L/min，V_p=60时135.6L/min，V_p=67时151.5L/min。流量约束Q<=Qa：V_p=48在transfer工况不足；V_p=60配V_m=55满足113.8<=135.6，配V_m=64满足132.4<=135.6；V_p=67均满足。泵轴功率P=2*dp*Q/(60*eta_pv*eta_pm)=dp*Q/24.84：候选P60_M55在transfer约6.69kW，climb约11.78kW，work_flat约5.94kW，均<=29.01kW。按目录排序规则先最小泵排量再最小马达排量，V_p=48不可行，故最小可行泵为60，马达55已满足，推荐P60_M55。

待核实事项：
- 未评价滑移与复杂土壤机理
- 未评价制动、动态、热平衡
- 未评价结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入耦合
- 本模型仅量化直行，转向负载未量化；连续半径转向与原地转向能力仅由左右独立HST构型定性支持，未做转向阻力矩与转向流量/压力校核

采用的完整输入见 final_design.json；独立评分未回传模型。
