# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动并保留既有固定总减速比26.37，与independent_hst（左右独立双HST，每侧一泵一马达，fixed_reduction_ratio=26.37）的接口和运动学能力一致；该构型支持continuous_radius与counterrotation_pivot，满足所需转向模式。

候选：P60_M51；输入版本：2。

计算依据：采用当前版本输入：working_mass=3806 kg，lambda=1.16，g=9.81，r=0.269 m，i=26.37，np=2529 r/min，行走功率预算34.01 kW，效率eta_pv=0.92、eta_pm=0.90、eta_mv=0.92、eta_mm=0.90、eta_g=0.95。按independent_hst模型逐工况计算F=lambda*m*g*(mu*cosθ+sinθ)、每侧马达扭矩T=F*r/(2*i*eta_g)、马达转速n=60*i*v/(2*pi*r)、压差dp=2*pi*T/(motor_ml_rev*eta_mm)、每侧马达流量Q=n*motor_ml_rev/(1000*eta_mv)、每侧泵可供流量Qa=pump_ml_rev*np*eta_pv/1000、两泵总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。对目录内6项候选（泵49/60/68 mL/rev × 马达51/58 mL/rev）执行match_hst与check_constraints：P49_M51与P49_M58在平地转场工况流量不足（分别需117.85、134.03 L/min，泵可供114.01 L/min）不通过；P60_M51、P60_M58、P68_M51、P68_M58通过全部已建模约束。按目录排序规则（先满足约束，再依次取较小泵排量、较小马达排量）选择P60_M51。其检查结果：平地作业F=3651.10 N≤附着20535.27 N，dp=2.683 MPa≤28 MPa，n=849.06 r/min≤3000 r/min，Q=47.07 L/min≤139.60 L/min，P=5.084 kW≤34.01 kW；平地转场F=1884.02 N≤24268.96 N，dp=1.385 MPa≤28 MPa，n=2125.92 r/min≤3000 r/min，Q=117.85 L/min≤139.60 L/min，P=6.569 kW≤34.01 kW；坡地直行F=11151.64 N≤20228.26 N，dp=8.196 MPa≤28 MPa，n=502.69 r/min≤3000 r/min，Q=27.87 L/min≤139.60 L/min，P=9.195 kW≤34.01 kW；泵转速2529 r/min≤3000 r/min。全部适用约束通过。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（模型仅量化直行）
- 未评价滑移与复杂土壤机理、动态过程、制动与再生工况
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价喂入量与作业速度耦合
- 候选排序按目录规则给出，非综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
