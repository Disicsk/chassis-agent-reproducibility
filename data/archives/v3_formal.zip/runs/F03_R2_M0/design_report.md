# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比；configuration_preference 为 independent_modular_left_right_drive，故采用 independent_hst：左右独立双HST，每侧一泵一马达，固定总减速比 i=25.8。该构型支持左右独立控制速度与换向，符合连续半径转向与反转向原地转向所需的左右独立驱动接口；本模型仅量化直行，转向负载未量化。

候选：P56_M58；输入版本：3。

计算依据：采用输入：m=4576 kg，g=9.81 m/s^2，lambda=1.12，r=0.24 m，i=25.8，np=2531 rpm，travel_shaft_power_budget_kw=31.52 kW，working_pressure_limit_mpa=28，motor_speed_limit_rpm=3000，pump_speed_limit_rpm=3000；效率 eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95。目录泵排量45/56/62 mL/rev，马达排量58/66 mL/rev。逐工况每侧计算：F=lambda*m*g*(mu*cos(theta)+sin(theta))；T=F*r/(2*i*eta_g)；n=60*i*v/(2*pi*r)；dp=2*pi*T/(motor_ml_rev*eta_mm)；Q=n*motor_ml_rev/(1000*eta_mv)；Qa=pump_ml_rev*np*eta_pv/1000；P=2*dp*Q/(60*eta_pv*eta_pm)。工况0 work_flat：theta=0，v=1.092，mu=0.0794，F≈3990 N，T≈19.5 N·m，n≈1121 rpm。工况1 transfer_flat：theta=0，v=1.829，mu=0.0413，F≈2076 N，T≈10.2 N·m，n≈1878 rpm。工况2 climb：theta=10.12°，v=0.625，mu=0.081，cos≈0.9844，sin≈0.1757，F≈12840 N，T≈62.9 N·m，n≈642 rpm。候选P56_M58：马达58 mL/rev。压力：工况2 dp=2*pi*62.9/(58*0.90)≈7.57 MPa≤28；工况0约2.35 MPa；工况1约1.22 MPa。转速：最大n≈1878 rpm≤3000。流量：工况1 Q=1878*58/(1000*0.92)≈118.4 L/min；泵56供流Qa=56*2531*0.92/1000≈130.4 L/min，Q≤Qa；工况2 Q≈40.5 L/min≤130.4；工况0 Q≈70.7 L/min≤130.4。功率：工况2 P=2*7.57*40.5/(60*0.92*0.90)≈12.3 kW≤31.52；工况1 P≈5.8 kW；工况0更小。附着：工况2 F≈12840 N≤0.55*4576*9.81*0.9844≈24300 N；工况0 F≈3990 N≤0.55*4576*9.81≈24690 N；工况1 F≈2076 N≤0.65*4576*9.81≈29170 N。泵45因工况1供流约104.8 L/min小于需求约118.4 L/min被排除；泵56、马达58满足全部已建模约束，按目录排序规则先最小泵排量再最小马达排量推荐P56_M58。

待核实事项：
- 未评价滑移与复杂土壤机理
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价实物安装干涉、采购可得性与作业喂入耦合
- independent_hst模型只量化直行，未量化转向负载；连续半径转向与反转向原地转向仅由构型接口支持，未做转向能力校核
- 未计内部循环功率损失与零速泄漏
- 仅支持稳态，acceleration_m_s2=0，不支持下坡制动、倒行/再生工况

采用的完整输入见 final_design.json；独立评分未回传模型。
