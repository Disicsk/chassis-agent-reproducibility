# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比25.8，与 independent_hst（左右独立双HST，每侧一泵一马达，经固定总减速比i驱动主动轮）的连接关系一致：发动机→左变量泵→左马达→左减速器→左履带，发动机→右变量泵→右马达→右减速器→右履带。该构型支持两侧独立调速与换向，具备 continuous_radius 与 counterrotation_pivot 的运动学能力。已按工程师确认写入 design_family=independent_hst。

候选：P56_M58；输入版本：3。

计算依据：采用输入：working_mass_kg=4576.0，drive_sprocket_effective_radius_m=0.24，fixed_reduction_ratio=25.8，pump_speed_rpm=2531.0，travel_shaft_power_budget_kw=31.52，load_factor=1.12，g=9.81；效率 pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95；限值 working_pressure_limit_mpa=28、motor_speed_limit_rpm=3000、pump_speed_limit_rpm=3000。工况：work_flat(slope 0°, speed 1.092 m/s, resistance 0.0794, adhesion 0.55)、transfer_flat(slope 0°, speed 1.829 m/s, resistance 0.0413, adhesion 0.65)、climb(slope 10.12°, speed 0.625 m/s, resistance 0.081, adhesion 0.55)。工具按 independent_hst 模型计算：F=lambda*m*g*(resistance*cosθ+sinθ)；每侧马达扭矩 T=F*r/(2*i*eta_g)；马达转速 n=60*i*v/(2*pi*r)；压差 dp=2*pi*T/(motor_ml_rev*eta_mm)；每侧马达流量 Q=n*motor_ml_rev/(1000*eta_mv)；每侧泵可供流量 Qa=pump_ml_rev*np*eta_pv/1000；两泵总轴功率 P=2*dp*Q/(60*eta_pv*eta_pm)。候选目录为泵排量[45,56,62] mL/rev、马达排量[58,66] mL/rev，共6个候选。工具约束检查结果：可行候选为 P56_M58、P62_M58、P62_M66；按排序规则（先满足约束，再依次最小泵排量、最小马达排量）推荐 P56_M58。P56_M58 逐工况检查：work_flat 设计力3992.03 N≤附着能力24689.81 N，压差2.353 MPa≤28 MPa，马达转速1120.99 r/min≤3000 r/min，泵转速2531 r/min≤3000 r/min，每侧马达流量70.67 L/min≤可供130.40 L/min，两泵总轴功率6.693 kW≤31.52 kW；transfer_flat 设计力2076.46 N≤29178.86 N，压差1.224 MPa≤28 MPa，马达转速1877.56 r/min≤3000 r/min，泵转速2531 r/min≤3000 r/min，每侧流量118.37 L/min≤130.40 L/min，总轴功率5.831 kW≤31.52 kW；climb 设计力12843.38 N≤24305.68 N，压差7.569 MPa≤28 MPa，马达转速641.59 r/min≤3000 r/min，泵转速2531 r/min≤3000 r/min，每侧流量40.45 L/min≤130.40 L/min，总轴功率12.325 kW≤31.52 kW。全部已建模约束通过。P45_M58 与 P45_M66 因 transfer_flat 流量不足被工具判为不可行。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（independent_hst 模型只量化直行，不量化转向负载）
- 未评价滑移与复杂土壤机理
- 未评价制动、动态过程、热平衡、结构强度与寿命
- 未评价实物安装干涉、采购可得性与作业喂入耦合
- 候选排序仅为按目录规则的推荐，不代表综合最优或真实成本最小
- 本方案为初步匹配，需工程人员独立复核后方可用于详细设计

采用的完整输入见 final_design.json；独立评分未回传模型。
