# 初步设计方案（待工程人员审核）

构型依据：采用工程师确认的 dual_power_stream 双功率流构型：直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速输出至左右履带，对应 configuration_preference=common_suns_opposing_rings_carrier_outputs。行星参数 sun=30、ring=90、planet=30 满足 Nr=sun+2*planet=30+60=90=ring，齿数为正整数，k=Nr/sun=3。驱动支路与转向支路各选1泵1马达，均在 illustrative_catalog 内：驱动泵49 mL/rev、驱动马达81 mL/rev；转向泵10 mL/rev、转向马达37 mL/rev。

候选：DP49_DM81_SP10_SM37；输入版本：3。

计算依据：采用输入：m=3695 kg，g=9.81，lambda=1.198，r=0.26 m，np=2522 rpm，行走泵轴功率预算30.35 kW；drive_input_reduction=0.993，steer_input_reduction=8.266，final_reduction=4.182；eta_pv=0.92，eta_pm=0.9，eta_mv=0.92，eta_mm=0.9，eta_g=0.95；压力上限28 MPa，马达/泵转速上限3000 rpm。运动学：A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.993*4.182)=0.06020；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.266*4.182)=0.02170。载荷：F=lambda*m*g*(mu*cos(theta)+sin(theta))。工况结果：work_flat F=3068 N，nd=589.4 rpm，Td=50.56 Nm；transfer_flat F=1645 N，nd=1200.1 rpm，Td=27.11 Nm；climb F=11728 N，nd=409.4 rpm，Td=193.3 Nm；gentle_turn F=3328 N，nd=460.0 rpm，Td=54.84 Nm，ns=251.5 rpm，Ts=7.95 Nm；pivot F=0，nd=0，ns=547.7 rpm，Ts=66.99 Nm。所选元件检查：驱动马达81 mL/rev时最大压力出现在climb，dp=2*pi*193.3/(81*0.9)=16.66 MPa<28；最大转速transfer为1200.1 rpm<3000；最大流量Q=1200.1*81/(1000*0.92)=105.66 L/min，驱动泵49 mL/rev可供Qa=49*2522*0.92/1000=113.68 L/min，满足Q<=Qa。转向马达37 mL/rev时最大压力pivot，dp=2*pi*66.99/(37*0.9)=12.64 MPa<28；最大转速547.7 rpm<3000；最大流量Q=547.7*37/(1000*0.92)=22.03 L/min，转向泵10 mL/rev可供Qa=10*2522*0.92/1000=23.20 L/min，满足Q<=Qa。泵转速2522 rpm<3000。功率：P=dp*Q/(60*eta_pv*eta_pm)=dp*Q/49.68；work_flat驱动4.55 kW；transfer驱动4.98 kW；climb驱动12.09 kW；gentle_turn驱动3.86+转向0.31=4.17 kW；pivot转向5.61 kW；各工况两支路泵轴功率之和均<=30.35 kW。附着：work_flat 3068<=0.55*3695*9.81=19937 N；transfer 1645<=0.65*3695*9.81=23561 N；climb 11728<=0.55*3695*9.81*cos(10.72deg)=19588 N；gentle_turn左右纵向力2333.6 N和994.4 N均<=0.65*3695*9.81/2=11780 N；pivot左右5637 N<=11780 N。所有可量化约束均满足。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本方案为履带式底盘准静态初步匹配，仅支持稳态，acceleration_m_s2=0，不支持下坡制动、倒行/再生工况。
- 转向仅按给定工况检查，未进行连续半径全范围与原地转向动态过程验证。

采用的完整输入见 final_design.json；独立评分未回传模型。
