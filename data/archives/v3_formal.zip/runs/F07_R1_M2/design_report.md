# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与 dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；check_configuration 返回 ok，能力覆盖 continuous_radius 与 counterrotation_pivot，满足 required_turn_modes。

候选：DP38_DM62_SP10_SM31；输入版本：3。

计算依据：输入版本3已通过 validate_requirements（ok）。行星参数 sun=30/ring=90/planet=30，k=Nr/Ns=3；A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.921*3.847)=0.07056，B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.297*3.847)=0.023497。载荷按 F=lambda*m*g*(mu*cosθ+sinθ) 逐工况计算：平地作业4039.0N、转场1893.9N、坡地13271.2N、缓弯3811.0N、原地0N；转向阻力矩按给定值（缓弯1067.8N·m、原地10481.3N·m）。候选 DP38_DM62_SP10_SM31（直行泵38/马达62，转向泵10/马达31）经 match_hst(scope=all) 枚举81项、check_constraints 全工况检查通过：坡地直行直行支路压力27.75MPa≤28MPa（最紧工况），原地转向支路压力19.72MPa≤28MPa，各工况马达转速最大950.6r/min≤3000r/min，泵转速2582r/min≤3000r/min，各支路需求流量均小于可用流量（直行90.27L/min、转向23.75L/min），左右纵向力均小于附着能力，泵轴功率合计最大11.88kW≤31.24kW。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未评价
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉及厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价

采用的完整输入见 final_design.json；独立评分未回传模型。
