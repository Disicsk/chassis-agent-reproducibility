# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比，故采用independent_hst（左右独立双HST）构型：发动机→左变量泵→左马达→左减速器→左履带，右侧同理。该构型支持两侧独立调速和换向，满足continuous_radius与counterrotation_pivot的运动学能力要求。

候选：P57_M51；输入版本：4。

计算依据：采用输入：working_mass_kg=4170、load_factor=1.205、g=9.81、drive_sprocket_effective_radius_m=0.246、fixed_reduction_ratio=29.34、pump_speed_rpm=2485、travel_shaft_power_budget_kw=33.47（已确认）、scenarios.1.speed_m_s=1.671（已确认）；效率pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95；限值working_pressure_limit_mpa=28、motor_speed_limit_rpm=3000、pump_speed_limit_rpm=3000。载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))计算，逐工况设计力：平地作业3573.80 N、平地转场1740.07 N、坡地直行11166.77 N；对应单侧马达扭矩15.77/7.68/49.28 N·m，马达转速1096.79/1903.15/765.36 r/min。候选P57_M51（每侧泵57 mL/rev、马达51 mL/rev）逐工况检查：压差2.159/1.051/6.746 MPa均≤28 MPa；马达转速均≤3000 r/min；泵转速2485 r/min≤3000 r/min；每侧马达流量60.80/105.50/42.43 L/min均≤可用泵流量130.31 L/min；两泵总轴功率5.284/4.464/11.522 kW均≤33.47 kW；附着力需求3573.80/1740.07/11166.77 N均≤可用22499.24/26590.01/22252.10 N。全部适用约束通过。目录内6个候选经全范围匹配，P57_M51、P57_M58、P64_M51、P64_M58可行；按目录排序规则（先满足约束，再最小泵排量、再最小马达排量）推荐P57_M51。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行，不量化转向负载）
- 未评价滑移与复杂土壤机理、动态过程、制动与再生工况
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行走速度耦合
- 双功率流内部循环功率损失与零速泄漏未计入（本方案为独立HST，不适用）

采用的完整输入见 final_design.json；独立评分未回传模型。
