# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致，对应dual_power_stream构型。check_configuration返回ok，configuration_id=dual_power_stream，支持continuous_radius与counterrotation_pivot，覆盖requirements.required_turn_modes。

候选：DP38_DM62_SP10_SM31；输入版本：3。

计算依据：采用当前case输入（input_version=3）：m=4013kg，g=9.81，lambda=1.182，r=0.25m，np=2582r/min，行走功率预算31.24kW，压力上限28MPa，马达转速上限3000r/min，泵转速上限3000r/min；行星参数sun=30、ring=90、planet=30，drive_input_reduction=0.921，steer_input_reduction=8.297，final_reduction=3.847，得k=3、A=0.07055994、B=0.02349730。载荷计算：F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))，各工况设计力分别为work_flat 4039.0N、transfer_flat 1893.9N、climb 13271.2N、gentle_turn 3811.0N、pivot 0N；转向阻力矩按给定值gentle_turn 1067.8N·m、pivot 10481.3N·m。候选DP38_DM62_SP10_SM31：直行支路泵38mL/rev、马达62mL/rev；转向支路泵10mL/rev、马达31mL/rev。check_constraints(scope=all)对81个候选检查后判定feasible_within_scope，该候选在全部5个工况通过已建模约束：左右纵向附着力均满足（最大需求7081.9N<可用12794.4N）；泵转速2582r/min<3000r/min；行走泵轴功率最大11.879kW<31.24kW；直行支路压力最大27.748MPa<28MPa（climb工况）；转向支路压力最大19.724MPa<28MPa（pivot工况）；直行马达转速最大950.6r/min<3000r/min；转向马达转速最大511.9r/min<3000r/min；直行流量最大64.06L/min<可用90.27L/min；转向流量最大17.25L/min<可用23.75L/min。该候选为满足约束后按直行泵、直行马达、转向泵、转向马达排量升序的推荐项，非综合最优。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未评价
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉及厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价
- 本方案为履带式底盘准静态初步匹配，仅覆盖稳态直行与给定转向工况，不支持加速、下坡制动、倒行/再生工况

采用的完整输入见 final_design.json；独立评分未回传模型。
