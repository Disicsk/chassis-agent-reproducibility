# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，配置偏好为common_suns_opposing_rings_carrier_outputs，与双功率流合成构型dual_power_stream一致；工具check_configuration返回ok，能力覆盖continuous_radius与counterrotation_pivot，满足所需转向模式。

候选：DP38_DM62_SP10_SM31；输入版本：4。

计算依据：采用当前case输入（input_version=4）：工作质量4013 kg、泵转速2582 r/min、主动轮有效半径0.25 m、履带中心距1.48 m、行走泵轴功率预算31.24 kW、压力上限28 MPa、马达/泵转速上限3000 r/min；行星参数sun=30、ring=90、planet=30，drive_input_reduction=0.921、steer_input_reduction=8.297、final_reduction=3.847，工具计算得k=3、A=0.07055993826852121、B=0.023497301366267816。载荷计算按各工况F=lambda*m*g*(resistance_coefficient*cosθ+sinθ)及双功率流左右速度/纵向力公式完成。候选DP38_DM62_SP10_SM31（直行泵38 mL/rev、直行马达62 mL/rev、转向泵10 mL/rev、转向马达31 mL/rev）在全部5个工况通过已建模约束：坡地直行工况直行支路压力27.747868187730603 MPa≤28 MPa、马达转速315.60344557944165 r/min≤3000 r/min、流量21.26892785426672 L/min≤90.26672 L/min、泵轴功率11.879376139181659 kW≤31.24 kW；原地转向工况转向支路压力19.72386910802804 MPa≤28 MPa、马达转速511.8523134230519 r/min≤3000 r/min、流量17.24719751751588 L/min≤23.7544 L/min、泵轴功率6.847453025680139 kW≤31.24 kW；缓弯转向工况直行支路压力7.968192370154216 MPa、转向支路压力2.009443957889859 MPa，两支路流量与转速均在上限内，泵轴功率合计4.671551127648813 kW≤31.24 kW；平地作业与平地转场工况各支路压力、转速、流量、功率及左右纵向附着均通过。各工况左右纵向力均不超过adhesion_coefficient*m*g*cosθ/2，泵转速2582 r/min≤3000 r/min。工具check_constraints返回feasible_within_scope，selected=DP38_DM62_SP10_SM31，failures为空。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着/纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖
- 本方案为按目录字典序推荐的可行候选，不代表综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
