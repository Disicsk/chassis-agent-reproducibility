# 初步设计方案（待工程人员审核）

构型依据：采用dual_power_stream双功率流构型，符合configuration_preference=common_suns_opposing_rings_carrier_outputs：直行马达同向驱动两太阳轮，转向马达反向驱动两齿圈，行星架经末级减速输出至左右履带。行星参数sun=30、ring=90、planet=30，Nr=sun+2*planet=90，k=Nr/sun=3。该构型可同时满足continuous_radius与counterrotation_pivot两类转向需求，且不采用fixed_reduction_ratio，速比由planetary定义。

候选：DP34_DM60_SP9_SM35；输入版本：2。

计算依据：输入采用当前case（input_version=2）：m=3934 kg，g=9.81，lambda=1.189，r=0.263 m，w=1.454 m，np=2467 rpm，预算30.16 kW，压力上限28 MPa，马达/泵转速上限3000 rpm；效率eta_pv=0.92、eta_pm=0.9、eta_mv=0.92、eta_mm=0.9、eta_g=0.95。行星：k=3，A=1/((1+k)*0.997*3.61)=1/14.39668≈0.0694605，B=3/((1+k)*7.437*3.61)=3/107.39028≈0.0279355。候选DP34_DM60_SP9_SM35：直行泵34 mL/rev、直行马达60 mL/rev、转向泵9 mL/rev、转向马达35 mL/rev。泵可供流量：直行Qa=34*2467*0.92/1000=77.17 L/min，转向Qa=9*2467*0.92/1000=20.43 L/min。逐工况核算：work_flat：F=4005.9 N，Td=76.99 Nm，nd=529.5 rpm，dp=8.96 MPa，Q=34.53 L/min，P=6.23 kW；transfer_flat(v=1.495)：F=1913.5 N，Td=36.77 Nm，nd=781.4 rpm，dp=4.28 MPa，Q=50.96 L/min，P=4.39 kW；climb：F=11389.7 N，Td=218.91 Nm，nd=320.4 rpm，dp=25.48 MPa，Q=20.90 L/min，P=10.72 kW；gentle_turn：F=3377.8 N，左/右纵向力994.9/2382.9 N，直行Td=64.91 Nm，nd=393.6 rpm，dp=7.55 MPa，Q=25.67 L/min，P_d=3.90 kW；转向Ts=10.74 Nm，ns=172.0 rpm，dp=2.14 MPa，Q=6.54 L/min，P_s=0.28 kW，合计4.18 kW；pivot：左右纵向力±5359.4 N，直行支路0；转向Ts=82.94 Nm，ns=346.3 rpm，dp=16.54 MPa，Q=13.17 L/min，P_s=4.39 kW。约束检查：各工况dp≤28 MPa（最大climb 25.48 MPa）；马达转速≤3000 rpm（最大transfer 781.4 rpm）；泵转速2467≤3000 rpm；各支路Q≤对应Qa；两支路泵轴功率之和≤30.16 kW（最大climb 10.72 kW）；左右纵向力绝对值≤adhesion*m*g*cosθ/2（climb约5694.9 N<10456.5 N，pivot约5359.4 N<12542.6 N）。缓弯满足v=0.753≥|yaw|*w/2=0.132 m/s；原地转向v=0且resistance_coefficient=0。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本方案为稳态准静态初步匹配，不支持加速、下坡制动、倒行/再生工况。
- 候选编号为目录排量类别，非厂家具体型号，需后续选型确认。

采用的完整输入见 final_design.json；独立评分未回传模型。
