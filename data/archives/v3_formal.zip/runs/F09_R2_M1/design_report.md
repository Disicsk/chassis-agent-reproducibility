# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与 dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；该构型支持 continuous_radius 与 counterrotation_pivot 两种必需转向模式，且不使用 fixed_reduction_ratio，速比由给定行星参数定义。

候选：DP33_DM55_SP10_SM29；输入版本：4。

计算依据：采用当前 case 输入：working_mass=3695 kg，r=0.26 m，np=2522 r/min，行走泵轴功率预算30.35 kW，行星 sun=30/planet=30/ring=90，drive_input_reduction=0.993，steer_input_reduction=8.266，final_reduction=4.182，效率与限值保持给定值。工具计算得 A=0.0602014、B=0.0216961、ring_sun_ratio=3.0。载荷：work_flat F=3070.15 N；transfer_flat F=1645.81 N；climb F=11729.79 N；gentle_turn F=3330.70 N、M=1212.86 N·m；pivot F=0、M=10215.59 N·m。候选 DP33_DM55_SP10_SM29 在全部5个工况通过已建模检查：各工况左右纵向力均小于对应附着能力（如 climb 5864.89 N < 9794.22 N，pivot 6756.34 N < 11780.58 N）；泵转速2522 r/min≤3000；直行支路最高压力24.53 MPa（climb）≤28 MPa，最高马达转速1200.04 r/min（transfer_flat）≤3000，最大流量71.74 L/min≤76.57 L/min；转向支路最高压力19.32 MPa（pivot）≤28 MPa，最高马达转速547.75 r/min≤3000，最大流量17.27 L/min≤23.20 L/min；各工况两泵轴功率合计最大12.08 kW（climb）≤30.35 kW。工具按排量升序推荐该候选，非综合最优。

待核实事项：
- 未评价滑移与复杂土壤机理、横向附着/纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价双功率流内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖

采用的完整输入见 final_design.json；独立评分未回传模型。
