# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比30.39，对应 independent_hst 构型（左右独立双HST，每侧一泵一马达，经固定减速比驱动主动轮）。check_configuration 已确认该构型具备 continuous_radius 与 counterrotation_pivot 能力，与 requirements.required_turn_modes 一致。

候选：P62_M58；输入版本：3。

计算依据：采用输入版本3（已通过 validate_requirements）。载荷按 F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta)) 计算，三工况设计力分别为：平地作业4375.57 N、平地转场2462.75 N、坡地直行14361.47 N。独立HST每侧马达扭矩 T=F*r/(2*i*eta_g)，转速 n=60*i*speed/(2*pi*r)，压差 dp=2*pi*T/(motor_ml_rev*eta_mm)，流量 Q=n*motor_ml_rev/(1000*eta_mv)，泵供流 Qa=pump_ml_rev*np*eta_pv/1000，两泵总轴功率 P=2*dp*Q/(60*eta_pv*eta_pm)。对目录内全部6个候选（泵50/62/70，马达58/67）执行 match_hst(scope=all) 与 check_constraints：P50_M58、P50_M67 在平地转场工况流量不足（需求117.27/135.46 L/min > 可用116.61 L/min）被排除；可行候选为 P62_M58、P62_M67、P70_M58、P70_M67。按目录排序规则（先满足约束，再依次取较小泵排量、较小马达排量）推荐 P62_M58（每侧泵62 mL/rev、马达58 mL/rev）。该候选三工况检查：平地作业 dp=2.47 MPa、n=1137.25 r/min、Q=71.70 L/min、P=7.13 kW；平地转场 dp=1.39 MPa、n=1860.08 r/min、Q=117.27 L/min、P=6.57 kW；坡地直行 dp=8.11 MPa、n=661.79 r/min、Q=41.72 L/min、P=13.63 kW。全部满足：附着力（设计力均小于对应附着能力）、压差≤28 MPa、马达转速≤3000 r/min、泵转速2535≤3000 r/min、流量Q≤Qa=144.60 L/min、行走泵轴功率≤31.92 kW（且≤发动机额定118 kW）。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行，转向能力仅确认结构/运动学）
- 未评价滑移与复杂土壤机理、动态过程
- 未评价制动、热平衡、结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入量与速度耦合
- 双功率流内部循环功率损失与零速泄漏未涉及（本构型不适用）

采用的完整输入见 final_design.json；独立评分未回传模型。
