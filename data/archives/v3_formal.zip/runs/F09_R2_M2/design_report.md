# 初步设计方案（待工程人员审核）

构型依据：需求明确直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream（common_suns_opposing_rings_carrier_outputs）构型一致；check_configuration确认该构型支持continuous_radius与counterrotation_pivot两种所需转向模式，履带中心距1.512 m已给出，满足原地转向要求。

候选：DP33_DM55_SP10_SM29；输入版本：3。

计算依据：输入校验通过（input_version=3，无缺项）。载荷计算（dual_power_stream_planetary_quasistatic_v1）：Nr=sun+2*planet=30+60=90，k=Nr/sun=3.0；A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.993*4.182)=0.060201；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.266*4.182)=0.021696。各工况按F=lambda*m*g*(rc*cosθ+sinθ)、左右速度v∓w*yaw/2、左右力F/2∓M/w计算，得直行马达nd=60*v/(2πr*A)、Td=A*r*F/eta_g，转向马达ns=60*w*yaw/(4πr*B)、Ts=2*B*r*M/(w*eta_g)。在允许目录内枚举全部81项候选（3×3×3×3），对全部候选执行约束检查。所选DP33_DM55_SP10_SM29（直行泵33/直行马达55/转向泵10/转向马达29 mL/rev）在五个工况下均通过：附着——左右纵向力最大为原地转向6756.3 N，均小于对应附着容量（平地作业9968.2 N、其余11780.6 N、坡地9794.2 N）；压力——直行支路最大24.53 MPa（坡地直行）、转向支路最大19.32 MPa（原地转向），均≤28 MPa；马达转速——直行最大1200.0 r/min、转向最大547.7 r/min，均≤3000 r/min；泵转速2522 r/min≤3000 r/min；流量——直行最大71.74 L/min≤76.57 L/min、转向最大17.27 L/min≤23.20 L/min；泵轴功率——最大12.08 kW（坡地直行）≤30.35 kW预算。check_constraints对全部81项候选的检查结果为feasible_within_scope，共36项可行，所选为按排量升序的推荐项。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未做
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉及厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价
- 本方案为准静态初步匹配，不支持下坡制动与倒行/再生工况

采用的完整输入见 final_design.json；独立评分未回传模型。
