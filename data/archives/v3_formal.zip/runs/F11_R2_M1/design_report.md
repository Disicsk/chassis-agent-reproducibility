# 初步设计方案（待工程人员审核）

构型依据：工程师明确要求直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，对应双功率流合成构型 dual_power_stream，配置偏好 common_suns_opposing_rings_carrier_outputs；该构型支持 continuous_radius 与 counterrotation_pivot 两种转向模式，与 required_turn_modes 一致。行星参数 sun_teeth=30、ring_teeth=90、planet_teeth=30 满足 Nr=sun+2*planet=90，k=Nr/sun=3。

候选：DP34_DM60_SP9_SM35；输入版本：2。

计算依据：采用最新确认输入：travel_shaft_power_budget_kw=30.16、transfer_flat 速度=1.495 m/s，其余输入保持当前 case。工具按 dual_power_stream_planetary_quasistatic_v1 计算：A=1/((1+k)*drive_input_reduction*final_reduction)=0.0694604589391443，B=k/((1+k)*steer_input_reduction*final_reduction)=0.027935489133653436。载荷：work_flat F=4005.894 N、transfer_flat F=1913.468 N、climb F=11389.732 N、gentle_turn F=3377.249 N 且 M=1199.820 N·m、pivot F=0 且 M=9265.164 N·m。候选 DP34_DM60_SP9_SM35 在全部 5 个工况通过已建模检查：各工况左右纵向力均不超过附着能力（如 climb 5694.866 N ≤ 10456.503 N，pivot 6372.190 N ≤ 12542.576 N）；泵转速 2467 r/min ≤ 3000 r/min；直行支路压力最大出现在 climb 为 25.484 MPa ≤ 28 MPa，转向支路压力最大出现在 pivot 为 19.660 MPa ≤ 28 MPa；直行马达最高转速出现在 transfer_flat 为 781.482 r/min ≤ 3000 r/min，转向马达最高转速出现在 pivot 为 346.312 r/min ≤ 3000 r/min；直行流量最大 50.966 L/min ≤ 77.168 L/min，转向流量最大 13.175 L/min ≤ 20.427 L/min；两支路泵轴功率之和最大出现在 climb 为 10.720 kW ≤ 30.16 kW。工具在 81 个目录候选中按排量升序推荐 DP34_DM60_SP9_SM35，且该候选在全部工况 passes_modeled_checks=true。

待核实事项：
- 未评价滑移、复杂土壤机理、横向附着与纵横向耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未计双功率流内部循环功率损失与零速保压泄漏
- 未评价具体齿轮布置、实物安装干涉与厂家产品可采购性
- 未评价喂入量与作业速度耦合
- 等效转向阻力矩的实测辨识与土壤机理预测未覆盖

采用的完整输入见 final_design.json；独立评分未回传模型。
