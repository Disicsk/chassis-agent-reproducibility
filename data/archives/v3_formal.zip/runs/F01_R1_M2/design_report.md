# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比30.39；configuration_preference=independent_modular_left_right_drive。据此选择 design_family=independent_hst（左右独立双HST，每侧一泵一马达，经固定减速比到主动轮），该构型检查通过并具备 continuous_radius 与 counterrotation_pivot 转向能力，与 required_turn_modes 一致。

候选：P62_M58；输入版本：3。

计算依据：采用当前 input_version=3 的已确认输入：working_mass_kg=5177、pump_speed_rpm=2535、drive_sprocket_effective_radius_m=0.271、fixed_reduction_ratio=30.39、load_factor=1.177、g=9.81、travel_shaft_power_budget_kw=31.92、效率(0.92/0.9/0.92/0.9/0.95)、限值(压力28MPa、马达3000rpm、泵3000rpm)。三工况载荷：F=lambda*m*g*(mu*cosθ+sinθ)，平地作业F=4375.57N、平地转场F=2462.75N、坡地直行F=14361.47N；每侧马达扭矩T=F*r/(2*i*eta_g)，转速n=60*i*v/(2*pi*r)。对允许目录6个候选枚举并检查约束，可行候选为P62_M58、P62_M67、P70_M58、P70_M67；按目录排序规则（先满足约束，再最小泵排量、再最小马达排量）推荐P62_M58。P62_M58（每侧泵62mL/rev、马达58mL/rev）逐工况检查：平地作业压力2.472MPa、马达转速1137.25rpm、每侧马达流量71.70L/min、泵可用流量144.60L/min、泵轴总功率7.135kW、附着力27932.5N>4375.57N；平地转场压力1.391MPa、转速1860.08rpm、流量117.27L/min<144.60L/min、功率6.568kW、附着力33011.1N>2462.75N；坡地直行压力8.113MPa、转速661.79rpm、流量41.72L/min、功率13.627kW、附着力27593.2N>14361.47N。全部工况压力<28MPa、马达转速<3000rpm、泵转速2535<3000rpm、流量满足、泵轴功率<31.92kW、附着力满足。P50_M58与P50_M67在平地转场流量不足（117.27/135.46L/min>116.61L/min）被排除。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行，转向负载未量化）
- 未评价滑移与复杂土壤机理、动态过程、制动与下坡制动、倒行/再生工况
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行驶速度耦合
- 双功率流内部循环功率损失与零速泄漏不适用（本方案为独立HST）

采用的完整输入见 final_design.json；独立评分未回传模型。
