# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自变量泵、马达与减速器驱动并保留既有固定总减速比，configuration_preference为independent_modular_left_right_drive，故采用independent_hst（左右独立双HST）。该构型经check_configuration确认具备continuous_radius与counterrotation_pivot能力，与required_turn_modes一致。

候选：P57_M51；输入版本：3。

计算依据：采用输入：working_mass_kg=4170、load_factor=1.205、g=9.81、drive_sprocket_effective_radius_m=0.246、fixed_reduction_ratio=29.34、pump_speed_rpm=2485、travel_shaft_power_budget_kw=33.47（已确认）、scenarios.1.speed_m_s=1.671（已确认）；效率pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95；限值working_pressure_limit_mpa=28、motor_speed_limit_rpm=3000、pump_speed_limit_rpm=3000。载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))计算：平地作业F=3573.80N、平地转场F=1740.07N、坡地直行F=11166.77N。每侧马达扭矩T=F*r/(2*i*eta_g)、转速n=60*i*speed/(2*pi*r)、压差dp=2*pi*T/(motor_ml_rev*eta_mm)、流量Q=n*motor_ml_rev/(1000*eta_mv)、泵供流Qa=pump_ml_rev*np*eta_pv/1000、总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。在目录（泵45/57/64，马达51/58）内枚举6个候选并做约束检查，可行候选为P57_M51、P57_M58、P64_M51、P64_M58；按偏好规则（先满足约束，再依次取较小泵排量、较小马达排量）选P57_M51（泵57mL/rev、马达51mL/rev）。所选候选三工况检查：平地作业dp=2.159MPa、n=1096.79r/min、Q=60.80L/min≤Qa=130.31L/min、P=5.284kW≤33.47kW、F=3573.80N≤附着力22499.24N；平地转场dp=1.051MPa、n=1903.15r/min、Q=105.50L/min≤130.31L/min、P=4.464kW≤33.47kW、F=1740.07N≤26590.01N；坡地直行dp=6.746MPa、n=765.36r/min、Q=42.43L/min≤130.31L/min、P=11.522kW≤33.47kW、F=11166.77N≤22252.10N。全部压力≤28MPa、马达转速≤3000r/min、泵转速2485r/min≤3000r/min，均通过。P45_M51与P45_M58因平地转场流量不足（105.50与119.98L/min>102.879L/min）未通过。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行，转向能力仅确认结构/运动学）
- 未评价滑移与复杂土壤机理、动态过程、制动与下坡再生
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行走速度耦合
- 双功率流内部循环功率损失与零速泄漏不适用（本方案为独立HST）

采用的完整输入见 final_design.json；独立评分未回传模型。
