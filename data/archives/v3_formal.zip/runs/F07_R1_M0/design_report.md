# 初步设计方案（待工程人员审核）

构型依据：需求指定直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速输出左右履带，configuration_preference=common_suns_opposing_rings_carrier_outputs，对应dual_power_stream双功率流构型。行星参数sun=30,ring=90,planet=30满足Nr=sun+2*planet=90，k=Nr/sun=3。直行支路与转向支路各一泵一马达，从目录内选择：直行泵38、直行马达62、转向泵10、转向马达19。

候选：DP38_DM62_SP10_SM19；输入版本：2。

计算依据：输入：m=4013kg,g=9.81,lambda=1.182,r=0.25m,w=1.48m,np=2582rpm；效率ηpv=0.92,ηpm=0.9,ηmv=0.92,ηmm=0.9,ηg=0.95；压力上限28MPa，马达转速上限3000rpm，泵转速上限3000rpm，行走功率预算31.24kW。行星k=3，A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.921*3.847)=0.07056，B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.297*3.847)=0.02350。逐工况F=lambda*m*g*(mu*cosθ+sinθ)：work_flat F≈4039N；transfer_flat F≈1894N；climb θ=12.17° F≈13272N；gentle_turn F≈3811N；pivot F=0。直行支路nd=60v/(2πrA)=541.4v，Td=A*r*F/ηg=0.018568F；转向支路ns=60w*yaw/(4πrB)=1202.8yaw，Ts=2BrM/(wηg)=0.008357M。压力dp=6.981T/motor_ml；流量Q=n*motor_ml/920；泵供流Qa=2.375*pump_ml；功率P=dp*Q/49.68。检查结果：直行马达62在climb工况dp=6.981*246.4/62≈27.75MPa≤28MPa，nd=315.6rpm≤3000rpm，Q=21.3L/min≤直行泵38供流90.3L/min，直行功率≈11.90kW；transfer工况nd=950.7rpm，Q=64.1L/min≤90.3L/min，dp≈3.96MPa，功率≈5.11kW；work_flat与gentle_turn均满足。转向马达19在pivot工况dp=6.981*74.1/19≈27.23MPa≤28MPa，ns=511.8rpm≤3000rpm，Q=10.57L/min≤转向泵10供流23.75L/min，转向功率≈5.79kW；gentle_turn工况dp≈2.77MPa，ns=254.9rpm，Q=5.26L/min，功率≈0.29kW。两支路泵轴功率之和最大约11.90kW（climb）≤31.24kW。附着检查：climb F=13272N≤0.55*4013*9.81*cos12.17°≈21180N；gentle_turn左右纵向力=1905.5±610.4N，最大2516N≤0.65*4013*9.81/2≈12794N；pivot左右纵向力=±5991N≤12794N。缓弯v=0.739≥|yaw|*w/2=0.1568m/s；原地转向v=0且resistance_coefficient=0。所有适用约束均通过。

待核实事项：
- 未评价滑移与复杂土壤机理
- 未评价制动、动态、热平衡、结构强度寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入耦合
- 双功率流未计内部循环功率损失与零速泄漏
- 本方案为初步匹配，需工程人员审核确认

采用的完整输入见 final_design.json；独立评分未回传模型。
