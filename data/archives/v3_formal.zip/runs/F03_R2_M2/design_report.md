# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比25.8；configuration_preference=independent_modular_left_right_drive，required_turn_modes包含continuous_radius与counterrotation_pivot。据此选择design_family=independent_hst（左右独立双HST），构型检查返回ok，能力覆盖continuous_radius与counterrotation_pivot，与需求一致。

候选：P56_M58；输入版本：4。

计算依据：采用input_version=4当前case输入：working_mass_kg=4576、load_factor=1.12、g=9.81、drive_sprocket_effective_radius_m=0.24、fixed_reduction_ratio=25.8、pump_speed_rpm=2531、travel_shaft_power_budget_kw=31.52、效率(0.92/0.90/0.92/0.90/0.95)、压力上限28MPa、马达转速上限3000r/min、泵转速上限3000r/min。三工况载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))计算：平地作业F=3992.03N、平地转场F=2076.46N、坡地直行F=12843.38N；每侧马达扭矩T=F*r/(2*i*eta_g)，马达转速n=60*i*speed/(2*pi*r)。在目录(泵45/56/62，马达58/66)内枚举6个候选并逐项检查附着、压力、马达转速、泵转速、流量与行走功率。可行候选为P56_M58、P62_M58、P62_M66；按目录排序规则(先满足约束，再依次取较小泵排量、较小马达排量)推荐P56_M58。P56_M58逐工况检查：平地作业压力2.353MPa、马达转速1120.99r/min、每侧马达流量70.67L/min、可用泵流量130.40L/min、泵轴总功率6.693kW、附着需求3992.03N<24689.81N；平地转场压力1.224MPa、马达转速1877.56r/min、每侧流量118.37L/min<130.40L/min、泵轴总功率5.831kW、附着需求2076.46N<29178.86N；坡地直行压力7.569MPa、马达转速641.59r/min、每侧流量40.45L/min、泵轴总功率12.325kW、附着需求12843.38N<24305.68N。全部压力<28MPa、马达转速<3000r/min、泵转速2531<3000r/min、流量满足、行走功率<31.52kW、附着满足，passes_modeled_checks=true。P45_M58与P45_M66因平地转场流量不足被排除。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，independent_hst模型仅量化直行，不量化转向负载
- 未评价滑移与复杂土壤机理
- 未评价制动、动态过程、热平衡、结构强度与寿命
- 未评价实物安装干涉与采购可得性
- 未评价作业喂入量与行走速度耦合
- 仅支持稳态，acceleration_m_s2=0，不支持下坡制动与倒行/再生工况

采用的完整输入见 final_design.json；独立评分未回传模型。
