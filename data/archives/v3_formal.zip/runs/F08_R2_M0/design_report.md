# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream构型及configuration_preference=common_suns_opposing_rings_carrier_outputs一致。行星齿数sun=30、planet=30、ring=90满足Nr=sun+2*planet=90，k=Nr/sun=3。直行支路与转向支路各一泵一马达，均在目录内选择：直行泵47mL/rev、直行马达58mL/rev、转向泵15mL/rev、转向马达31mL/rev。

候选：DP47_DM58_SP15_SM31；输入版本：2。

计算依据：采用输入：m=4000kg，lambda=1.172，g=9.81，r=0.271m，w=1.451m，np=2426rpm，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95，压力上限28MPa，马达转速上限3000rpm，泵转速上限3000rpm，行走功率预算31.65kW。行星：k=3，A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*1.008*3.931)=0.06310；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*7.421*3.931)=0.02571。逐工况F=lambda*m*g*(mu*cos(theta)+sin(theta))：work_flat F=3537N；transfer_flat F=1642N；climb F=11602N；gentle_turn F=3335N、M=931Nm；pivot F=0、M=9851.7Nm。直行支路nd=60*v/(2*pi*r*A)=558.5*v，Td=A*r*F/eta_g=0.01800*F；转向支路ns=60*w*yaw/(4*pi*r*B)=994.4*yaw，Ts=2*B*r*M/(w*eta_g)=0.010105*M。所选直行马达58mL/rev：dp=2*pi*Td/(58*0.9)=0.1204*Td，最大climb为25.14MPa<=28；Q=nd*58/(1000*0.92)=0.06304*nd，最大transfer_flat为70.38L/min，直行泵47供流Qa=47*2426*0.92/1000=104.9L/min，满足。所选转向马达31mL/rev：dp=0.2252*Ts，最大pivot为22.42MPa<=28；Q=0.03370*ns，最大pivot为14.01L/min，转向泵15供流Qa=15*2426*0.92/1000=33.48L/min，满足。转速：直行马达最大1116.5rpm、转向马达最大415.6rpm、泵2426rpm，均<=3000rpm。功率：P=dp*Q/(60*eta_pv*eta_pm)=dp*Q/49.68，各工况两泵轴功率和最大为climb约11.28kW，均<=31.65kW。附着力：直行工况F<=mu*m*g*cos(theta)，climb为11602N<=21278N；gentle_turn左右纵向力约2309N与1026N，pivot约±6789N，均<=0.65*4000*9.81/2=12753N。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本方案为稳态初步匹配，不支持加速、下坡制动、倒行/再生工况。
- 候选编号为目录排量组合，不代表真实厂家型号或成本最优。

采用的完整输入见 final_design.json；独立评分未回传模型。
