# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自变量泵、马达与减速器驱动，并保留既有固定总减速比，configuration_preference=independent_modular_left_right_drive，故采用independent_hst：左右各一泵一马达，每侧独立控制速度与换向；固定总减速比i=26.37用于马达到主动轮。目录中泵排量[49,60,68] mL/rev、马达排量[51,58] mL/rev，按目录排序规则先最小泵排量再最小马达排量筛选。

候选：P60_M51；输入版本：2。

计算依据：采用最新输入：travel_shaft_power_budget_kw=34.01，transfer_flat速度=2.271 m/s，其余沿用当前case。输入：m=3806 kg，lambda=1.16，g=9.81，r=0.269 m，i=26.37，eta_g=0.95，eta_mm=0.9，eta_mv=0.92，eta_pv=0.92，eta_pm=0.9，np=2529 rpm，压力上限28 MPa，马达/泵转速上限3000 rpm。公式：theta=slope*pi/180；F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))；T=F*r/(2*i*eta_g)；n=60*i*speed/(2*pi*r)；dp=2*pi*T/(motor_ml*eta_mm)；Q=n*motor_ml/(1000*eta_mv)；Qa=pump_ml*np*eta_pv/1000；P=2*dp*Q/(60*eta_pv*eta_pm)。工况1 work_flat：v=0.907，slope=0，mu_r=0.0843，adhesion=0.55；F=3651.10 N，T=19.60 Nm，n=849.06 rpm。P60_M51：dp=2.683 MPa<=28；Q=47.07 L/min<=Qa=139.60 L/min；P=5.08 kW<=34.01；F<=0.55*3806*9.81=20535 N；n<=3000；np=2529<=3000。工况2 transfer_flat：v=2.271，slope=0，mu_r=0.0435，adhesion=0.65；F=1884.02 N，T=10.11 Nm，n=2125.79 rpm。P60_M51：dp=1.385 MPa<=28；Q=117.84 L/min<=Qa=139.60 L/min；P=6.57 kW<=34.01；F<=0.65*3806*9.81=24268.96 N；n<=3000；np<=3000。原P49_M51在该工况Q=117.84 L/min>Qa=114.01 L/min，流量不足，故排除。工况3 climb：v=0.537，slope=9.92，mu_r=0.0865，adhesion=0.55；theta=0.17314 rad，cos=0.98505，sin=0.17230；F=11151.64 N，T=59.87 Nm，n=502.69 rpm。P60_M51：dp=8.196 MPa<=28；Q=27.87 L/min<=139.60；P=9.19 kW<=34.01；F<=0.55*3806*9.81*0.98505=20228.26 N；n<=3000；np<=3000。按目录排序规则，P60_M51为满足全部已建模约束的最小泵排量候选；P60_M58虽也可能满足但马达排量更大，不优先。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 独立HST模型只量化直行，不量化转向负载；required_turn_modes中的continuous_radius与counterrotation_pivot未在本计算模型中量化。
- 未进行下坡制动、倒行/再生工况评价。
- 效率、功率预算和元件目录均按给定值采用，未做实物校核。

采用的完整输入见 final_design.json；独立评分未回传模型。
