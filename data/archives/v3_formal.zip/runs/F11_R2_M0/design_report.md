# 初步设计方案（待工程人员审核）

构型依据：采用双功率流构型：直行马达同向输入两太阳轮，转向马达反向输入两齿圈，行星架经末级减速驱动左右履带，符合 requirements.configuration_preference=common_suns_opposing_rings_carrier_outputs 及 required_turn_modes=[continuous_radius,counterrotation_pivot]。行星齿数 sun=30、ring=90、planet=30，Nr=sun+2*planet=90，k=Nr/sun=3。元件均取自当前 illustrative_catalog：直行泵34 mL/rev、直行马达60 mL/rev、转向泵15 mL/rev、转向马达35 mL/rev。

候选：DP34_DM60_SP15_SM35；输入版本：2。

计算依据：输入采用当前版本2：travel_shaft_power_budget_kw=30.16，scenarios.1.speed_m_s=1.495，其余沿用当前case已公开值。行星系数 A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.997*3.61)=0.0694605；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*7.437*3.61)=0.0279355。共同载荷 F=lambda*m*g*(resistance_coefficient*cosθ+sinθ)，lambda=1.189，m=3934 kg，g=9.81 m/s²，m*g=38592.54 N。逐工况检查如下。work_flat：F≈4005.89 N；直行 nd≈529.53 r/min，Td≈77.03 Nm，dp≈8.963 MPa≤28，Q≈34.53 L/min≤Qa_drive=34*2467*0.92/1000≈77.17 L/min，P≈6.23 kW；转向支路 yaw=0，ns=Ts=dp=Q=P=0；左右纵向力≈2002.95 N≤0.55*38592.54/2≈10612.95 N；总功率≈6.23 kW≤30.16 kW。transfer_flat：v=1.495 m/s，F≈1913.47 N；nd≈781.55 r/min，Td≈36.80 Nm，dp≈4.281 MPa≤28，Q≈50.97 L/min≤77.17，P≈4.39 kW；左右力≈956.73 N≤0.65*38592.54/2≈12542.58 N；总功率≈4.39 kW≤30.16 kW。climb：θ=9.85°，F≈11389.73 N；nd≈320.43 r/min，Td≈219.02 Nm，dp≈25.484 MPa≤28，Q≈20.90 L/min≤77.17，P≈10.72 kW；左右力≈5694.87 N≤0.55*38592.54*cos9.85°/2≈10456.50 N；总功率≈10.72 kW≤30.16 kW。gentle_turn：v=0.753 m/s，yaw=0.182 rad/s，w=1.454 m，M=1009.1 Nm；左/右速度≈0.6207/0.8853 m/s，左/右纵向力≈994.66/2382.70 N≤12542.58 N；直行支路 nd≈393.62 r/min，Td≈64.94 Nm，dp≈7.556 MPa≤28，Q≈25.67 L/min≤77.17，P≈3.90 kW；转向支路 ns≈171.97 r/min≤3000，Ts≈10.735 Nm，dp=2π*10.735/(35*0.9)≈2.141 MPa≤28，Q≈11.22 L/min≤Qa_steer=15*2467*0.92/1000≈34.04 L/min，P≈0.484 kW；总功率≈4.38 kW≤30.16 kW。pivot：v=0，yaw=0.3665 rad/s，M=7792.4 Nm；直行支路 nd=Td=dp=Q=P=0；转向支路 ns≈346.31 r/min≤3000，Ts≈82.90 Nm，dp=2π*82.90/(35*0.9)≈16.54 MPa≤28，Q≈22.59 L/min≤34.04 L/min，P≈7.52 kW；左右纵向力=M/w≈5359.42 N≤0.65*38592.54/2≈12542.58 N；总功率≈7.52 kW≤30.16 kW。泵转速均为2467 r/min≤3000 r/min。所有适用约束：压力、马达转速、泵转速、流量、附着力和行走泵轴功率预算均满足。

待核实事项：
- 双功率流模型未计内部循环功率损失与零速泄漏。
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 本方案为按公开目录与给定公式完成的准静态初步匹配，不替代最终独立工程审核。

采用的完整输入见 final_design.json；独立评分未回传模型。
