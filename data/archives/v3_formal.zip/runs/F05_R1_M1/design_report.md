# 初步设计方案（待工程人员审核）

构型依据：工程师要求左右履带分别由各自变量泵、马达与减速器驱动并保留既有固定总减速比，configuration_preference为independent_modular_left_right_drive，故采用independent_hst（左右独立双HST）：发动机→左变量泵→左马达→左减速器→左履带，右侧同构。该构型支持两侧独立调速与换向，满足continuous_radius与counterrotation_pivot的运动学能力；本模型仅量化直行，不量化转向负载。

候选：P52_M53；输入版本：2。

计算依据：采用最新确认输入：travel_shaft_power_budget_kw=33.1，scenarios.1.speed_m_s=1.731，其余输入与效率、限值保持原值；fixed_reduction_ratio=27.63，r=0.239 m，np=2632 r/min，lambda=1.164，g=9.81。载荷按F=lambda*m*g*(resistance_coefficient*cos(theta)+sin(theta))计算：work_flat F=3937.79 N、transfer_flat F=2256.36 N、climb F=12941.62 N。独立HST每侧马达扭矩T=F*r/(2*i*eta_g)，转速n=60*i*speed/(2*pi*r)，压差dp=2*pi*T/(motor_ml_rev*eta_mm)，流量Q=n*motor_ml_rev/(1000*eta_mv)，泵可供流Qa=pump_ml_rev*np*eta_pv/1000，两泵总轴功率P=2*dp*Q/(60*eta_pv*eta_pm)。在目录泵排量[42,52,58]、马达排量[53,61]共6个候选中，工具按约束筛选后可行候选为P52_M53、P58_M53、P58_M61；按排序规则（先满足约束，再依次取较小泵排量、较小马达排量）推荐P52_M53。所选P52_M53（每侧泵52 mL/rev、马达53 mL/rev）逐工况检查：work_flat 压力2.361 MPa≤28、马达转速968.18≤3000 r/min、泵转速2632≤3000 r/min、流量55.78≤125.91 L/min、行走功率5.302 kW≤33.1 kW、附着力需求3937.79 N≤25628.63 N；transfer_flat 压力1.353 MPa≤28、马达转速1910.96≤3000 r/min、流量110.09≤125.91 L/min、行走功率5.997 kW≤33.1 kW、附着力需求2256.36 N≤30288.38 N；climb 压力7.761 MPa≤28、马达转速695.50≤3000 r/min、流量40.07≤125.91 L/min、行走功率12.518 kW≤33.1 kW、附着力需求12941.62 N≤25284.49 N。全部适用约束通过。对比P42_M53与P42_M61在transfer_flat流量分别需110.09、126.70 L/min，超过其可供101.70 L/min，故不满足。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率，双功率流内部循环功率损失与零速泄漏亦未计；本模型仅量化直行。
- 未评价滑移与复杂土壤机理、制动、动态过程、热平衡、结构强度与寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 仅支持稳态，acceleration_m_s2=0，不支持下坡制动、倒行/再生工况。
- 候选排序为按约束筛选后取较小排量，不代表综合最优或真实成本最小。

采用的完整输入见 final_design.json；独立评分未回传模型。
