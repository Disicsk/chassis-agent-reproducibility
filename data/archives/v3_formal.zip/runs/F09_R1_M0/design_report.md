# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，与dual_power_stream构型定义一致；行星参数sun=30、ring=90、planet=30满足Nr=sun+2*planet=90，k=Nr/sun=3。元件仅从目录选择：直行泵49 mL/rev、直行马达81 mL/rev、转向泵24 mL/rev、转向马达37 mL/rev，均在illustrative_catalog的drive/steering排量列表内。

候选：DP49_DM81_SP24_SM37；输入版本：3。

计算依据：采用已确认输入：m=3695 kg，g=9.81，lambda=1.198，r=0.26 m，np=2522 r/min，行走泵轴功率预算30.35 kW，压力上限28 MPa，马达转速上限3000 r/min，泵转速上限3000 r/min；效率eta_pv=0.92、eta_pm=0.90、eta_mv=0.92、eta_mm=0.90、eta_g=0.95。行星：k=3，A=1/((1+k)*drive_input_reduction*final_reduction)=1/(4*0.993*4.182)=0.06020；B=k/((1+k)*steer_input_reduction*final_reduction)=3/(4*8.266*4.182)=0.02170。逐工况载荷F=lambda*m*g*(mu*cosθ+sinθ)。直行支路：nd=60*v/(2π*r*A)，Td=A*r*F/eta_g，dp=2π*Td/(motor*eta_mm)，Q=nd*motor/(1000*eta_mv)，Qa=pump*np*eta_pv/1000，P=dp*Q/(60*eta_pv*eta_pm)。转向支路：ns=60*w*yaw/(4π*r*B)，Ts=2*B*r*M/(w*eta_g)，其余同式。计算得：work_flat F=3069 N、nd=589.6 r/min、Td=50.6 N·m、dp=4.36 MPa、Q=51.9 L/min、P=4.55 kW；transfer_flat F=1645 N、nd=1200.6 r/min、Td=27.1 N·m、dp=2.34 MPa、Q=105.7 L/min、P=4.98 kW；climb F=11725 N、nd=409.5 r/min、Td=193.3 N·m、dp=16.65 MPa、Q=36.1 L/min、P=12.10 kW；gentle_turn直行F=3330 N、nd=460.2 r/min、Td=54.9 N·m、dp=4.73 MPa、Q=40.5 L/min、P=3.86 kW，转向ns=251.5 r/min、Ts=7.95 N·m、dp=1.50 MPa、Q=10.1 L/min、P=0.31 kW；pivot转向ns=547.7 r/min、Ts=67.0 N·m、dp=12.64 MPa、Q=22.0 L/min、P=5.60 kW。约束检查：直行泵Qa=49*2522*0.92/1000=113.7 L/min，转向泵Qa=24*2522*0.92/1000=55.7 L/min，各工况Q均不超过对应Qa；两支路dp最大16.65 MPa<=28 MPa；abs(n)最大直行1200.6 r/min、转向547.7 r/min<=3000 r/min；泵转速2522<=3000 r/min；两支路泵轴功率之和最大为climb约12.10 kW、gentle_turn约4.17 kW、pivot约5.60 kW，均<=30.35 kW；附着检查：climb F=11725 N<=0.55*3695*9.81*cos10.72°=19590 N，gentle_turn左右纵向力约995.4 N与2334.6 N均<=0.65*3695*9.81/2=11778 N，pivot M/w=5639.7 N<=11778 N。

待核实事项：
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 双功率流未计内部循环功率损失与零速泄漏。
- 本计算为履带式底盘准静态初步匹配，仅支持稳态，acceleration_m_s2=0，不支持下坡制动、倒行/再生工况。
- 转向负载仅按给定yaw_rate与turn_resistance_moment量化，未进行复杂转向动力学验证。

采用的完整输入见 final_design.json；独立评分未回传模型。
