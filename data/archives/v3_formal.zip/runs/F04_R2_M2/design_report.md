# 初步设计方案（待工程人员审核）

构型依据：需求明确左右履带分别由各自的变量泵、马达与减速器驱动并保留既有固定总减速比，configuration_preference=independent_modular_left_right_drive，故采用independent_hst（左右独立双HST）。该构型经check_configuration确认具备continuous_radius与counterrotation_pivot能力，满足required_turn_modes。

候选：P57_M51；输入版本：3。

计算依据：采用输入：working_mass_kg=4170、load_factor=1.205、g=9.81、r=0.246m、i=29.34、pump_speed_rpm=2485、功率预算33.47kW、压力上限28MPa、马达转速上限3000r/min、泵转速上限3000r/min；效率pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95。三工况载荷F=lambda*m*g*(mu*cosθ+sinθ)：work_flat F=3573.80N、transfer_flat F=1740.07N、climb F=11166.77N。每侧马达扭矩T=F*r/(2*i*eta_g)，转速n=60*i*v/(2*pi*r)。候选P57_M51（泵57mL/rev、马达51mL/rev，各2件）逐工况检查：work_flat dp=2.159MPa、n=1096.79r/min、每侧流量60.80L/min、泵可供130.31L/min、总轴功率5.284kW；transfer_flat dp=1.051MPa、n=1903.15r/min、流量105.50L/min、可供130.31L/min、功率4.464kW；climb dp=6.746MPa、n=765.36r/min、流量42.43L/min、可供130.31L/min、功率11.522kW。全部工况附着F<=mu*m*g*cosθ、dp<=28MPa、n<=3000r/min、np=2485<=3000r/min、Q<=Qa、P<=33.47kW均通过。check_constraints(scope=all)结果feasible_within_scope，可行候选为P57_M51、P57_M58、P64_M51、P64_M58；按目录排序规则（先满足约束再取较小泵排量、较小马达排量）推荐P57_M51。P45_M51与P45_M58因transfer_flat流量不足未通过。

待核实事项：
- 未评价土壤转向阻力及转向压力/功率（本模型仅量化直行）
- 未评价滑移与复杂土壤机理、动态过程、制动与再生工况
- 未评价热平衡、结构强度与寿命、实物安装干涉、采购可得性
- 未评价作业喂入量与行走速度耦合
- 双功率流内部循环功率损失与零速泄漏未涉及（本方案为独立HST）

采用的完整输入见 final_design.json；独立评分未回传模型。
