# 初步设计方案（待工程人员审核）

构型依据：需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，属直行/转向双功率流行星合成构型，与configuration_preference=common_suns_opposing_rings_carrier_outputs一致；工具check_configuration返回configuration_id=dual_power_stream，能力覆盖continuous_radius与counterrotation_pivot，满足required_turn_modes。故design_family采用dual_power_stream，不使用fixed_reduction_ratio，速比由planetary给定齿数与各输入/末级减速定义。

候选：DP33_DM55_SP10_SM29；输入版本：3。

计算依据：采用输入：working_mass_kg=3695、g=9.81、load_factor=1.198、r=0.26 m、np=2522 r/min、行走泵轴功率预算30.35 kW、压力上限28 MPa、马达/泵转速上限3000 r/min；行星sun=30、ring=90、planet=30，drive_input_reduction=0.993、steer_input_reduction=8.266、final_reduction=4.182；效率0.92/0.90/0.92/0.90/0.95。工具calculate_loads得ring_sun_ratio k=3.0，A=0.0602014、B=0.0216961。各工况载荷：平地作业F=3070.15 N、平地转场F=1645.81 N、坡地直行F=11729.79 N、缓弯F=3330.70 N且M=1212.86 N·m、原地转向F=0且M=10215.59 N·m。工具match_hst在全部81个目录组合中检查，feasible_ids共36项；工具check_constraints按排量升序推荐DP33_DM55_SP10_SM29（直行泵33/马达55，转向泵10/马达29）。该候选逐工况检查：左右纵向力均不超过各自附着能力（如坡地直行5864.89 N≤9794.22 N，原地转向6756.34 N≤11780.58 N）；泵转速2522≤3000 r/min；直行支路最高压力出现在坡地直行24.53 MPa≤28 MPa，转向支路最高压力出现在原地转向19.32 MPa≤28 MPa；直行马达最高转速1200.04 r/min、转向马达最高转速547.75 r/min，均≤3000 r/min；直行流量最大71.74 L/min≤76.57 L/min，转向流量最大17.27 L/min≤23.20 L/min；泵轴功率合计最大为坡地直行12.08 kW≤30.35 kW。工具返回status=feasible_within_scope、passes_modeled_checks=true、failures为空。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未评价
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、安装干涉与厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价
- 本方案为按目录排量升序的可行候选，非综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
