# 初步设计方案（待工程人员审核）

构型依据：文字明确“直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带”，与 configuration_preference=common_suns_opposing_rings_carrier_outputs 一致，故采用 dual_power_stream 双功率流合成构型，不使用 fixed_reduction_ratio。行星参数 sun=30、ring=90、planet=30 满足 Nr=sun+2*planet=90=ring 且齿数为正整数，k=Nr/sun=3；工具计算得 A=0.07055993826852121、B=0.023497301366267816。构型能力覆盖 required_turn_modes=[continuous_radius, counterrotation_pivot]。

候选：DP38_DM62_SP10_SM31；输入版本：2。

计算依据：采用输入（input_version=2）：working_mass_kg=4013、load_factor=1.182、g=9.81、r=0.25、w=1.48、pump_speed_rpm=2582、travel_shaft_power_budget_kw=31.24、engine_rated_power_kw=110、压力上限28MPa、马达/泵转速上限3000rpm；效率 pump_volumetric=0.92、pump_mechanical=0.9、motor_volumetric=0.92、motor_mechanical=0.9、mechanical_reduction=0.95；行星 drive_input_reduction=0.921、steer_input_reduction=8.297、final_reduction=3.847。目录 drive 泵[38,49,57]/马达[62,71,90]、steering 泵[10,16,24]/马达[19,31,38]，各1泵1马达，组合 3*3*3*3=81≤2500，工具已对全部81个候选执行检查。工具按“满足约束后直行泵、直行马达、转向泵、转向马达排量升序”规则推荐 DP38_DM62_SP10_SM31（直行泵38/直行马达62/转向泵10/转向马达31），该候选在全部五工况通过已建模约束检查（passes_modeled_checks=true，failures=[]）。关键工具计算事实：work_flat 直行支路 dp=8.4449MPa、n=528.35rpm、Q=35.606L/min≤Qa=90.267L/min、泵轴功率合计6.0526kW≤31.24kW，左右纵向力各2019.51N≤附着能力10826.07N；transfer_flat 直行 dp=3.9598MPa、n=950.60rpm、Q=64.062L/min、功率5.1061kW，左右力各946.93N≤12794.45N；climb 直行 dp=27.7479MPa≤28MPa（最紧工况）、n=315.60rpm、Q=21.269L/min、功率11.8794kW，左右力各6635.59N≤10582.77N；gentle_turn 直行 dp=7.9682MPa、n=400.05rpm、Q=26.960L/min，转向支路 dp=2.0094MPa、n=254.90rpm、Q=8.589L/min≤Qa=23.754L/min，功率合计4.6716kW，左右力1184.00N/2627.00N≤12794.45N，且 v=0.739≥|yaw|*w/2=0.1568；pivot 转向支路 dp=19.7239MPa≤28MPa、n=511.85rpm、Q=17.247L/min≤23.754L/min、功率6.8475kW，左右力各7081.94N≤12794.45N，speed=0、resistance_coefficient=0 符合原地转向边界。泵转速2582rpm≤3000rpm 全工况通过。上述数值均为工具返回事实，未作改写。

待核实事项：
- 等效转向阻力矩的实测辨识与土壤机理预测未评价
- 横向附着、纵横向耦合与滑移未评价
- 动态、制动、热平衡、结构强度与寿命未评价
- 双功率流内部循环功率损失与零速保压泄漏未计入
- 具体齿轮布置、实物安装干涉与厂家产品可采购性未评价
- 喂入量与作业速度耦合未评价
- 本方案为按公开模型与目录的准静态初步匹配，需工程人员独立复核后方可用于详细设计

采用的完整输入见 final_design.json；独立评分未回传模型。
