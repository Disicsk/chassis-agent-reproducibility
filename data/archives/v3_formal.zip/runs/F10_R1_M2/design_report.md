# 初步设计方案（待工程人员审核）

构型依据：工程师需求明确为直行马达同向输入两太阳轮、转向马达反向输入两齿圈、行星架经末级减速驱动左右履带，对应dual_power_stream（common_suns_opposing_rings_carrier_outputs）。check_configuration返回configuration_id=dual_power_stream，能力覆盖continuous_radius与counterrotation_pivot，满足requirements.required_turn_modes。行星参数sun=30、ring=90、planet=30满足Nr=sun+2*planet=90，k=3。

候选：DP43_DM66_SP10_SM22；输入版本：3。

计算依据：采用当前版本3输入：working_mass=4171kg，pump_speed=2557r/min，r=0.232m，w=1.506m，lambda=1.204，g=9.81，效率0.92/0.90/0.92/0.90/0.95，压力上限28MPa，马达/泵转速上限3000r/min，行走功率预算30.58kW（已确认），转场速度1.863m/s（已确认）。calculate_loads给出A=0.0684178、B=0.0235762、k=3。候选DP43_DM66_SP10_SM22：直行泵43mL/rev、直行马达66mL/rev、转向泵10mL/rev、转向马达22mL/rev。逐工况关键检查：平地作业直行压力6.57MPa、马达531.2r/min、流量38.11L/min、泵轴功率5.04kW；转场直行压力3.51MPa、马达1120.8r/min、流量80.40L/min、泵轴功率5.68kW；坡地直行压力25.33MPa（<28）、马达395.9r/min、流量28.40L/min、泵轴功率14.48kW；缓弯直行压力7.38MPa、转向压力3.06MPa、转向马达248.1r/min、转向流量5.93L/min、合计泵轴功率4.95kW；原地转向转向压力25.30MPa（<28）、转向马达558.6r/min、转向流量13.36L/min、泵轴功率6.80kW。各工况左右纵向力均小于单侧附着能力（如坡地7166.9N<11009.3N，原地6924.2N<13298.2N），泵转速2557r/min<3000r/min，各支路流量均小于对应可用泵流量（直行101.15L/min、转向23.52L/min），两支路泵轴功率之和最大14.48kW<30.58kW。check_constraints(scope=all)在81个候选中判定24个可行，本候选为按排量升序推荐的首个可行项，failures为空。

待核实事项：
- 未评价滑移与复杂土壤机理、横纵向附着耦合
- 未评价制动、动态、热平衡、结构强度与寿命
- 未评价实物安装干涉、采购可得性与喂入量耦合
- 双功率流未计内部循环功率损失与零速泄漏
- 等效转向阻力矩为给定值，未做实测辨识
- 候选选择按目录排量升序推荐，非综合最优或真实成本最小

采用的完整输入见 final_design.json；独立评分未回传模型。
