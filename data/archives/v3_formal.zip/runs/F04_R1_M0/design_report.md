# 初步设计方案（待工程人员审核）

构型依据：需求为左右履带分别由各自的变量泵、马达与减速器驱动，并保留既有固定总减速比；configuration_preference=independent_modular_left_right_drive，故采用independent_hst：每侧一泵一马达，共2泵2马达。采用当前case已确认输入：working_mass_kg=4170.0、pump_speed_rpm=2485.0、drive_sprocket_effective_radius_m=0.246、fixed_reduction_ratio=29.34、scenarios.0.speed_m_s=0.963、scenarios.1.speed_m_s=1.671、scenarios.2.slope_deg=8.5、travel_shaft_power_budget_kw=33.47。目录内泵排量45/57/64 mL/rev、马达排量51/58 mL/rev，候选编号按P{泵}_M{马达}语法填写。

候选：P57_M51；输入版本：3。

计算依据：共同参数：lambda=1.205，g=9.81，eta_pv=0.92，eta_pm=0.90，eta_mv=0.92，eta_mm=0.90，eta_g=0.95，压力上限28 MPa，马达/泵转速上限3000 r/min，功率预算33.47 kW。逐工况F=lambda*m*g*(mu_r*cosθ+sinθ)，T=F*r/(2*i*eta_g)，n=60*i*v/(2*pi*r)，dp=2*pi*T/(motor_ml*eta_mm)，Q=n*motor_ml/(1000*eta_mv)，Qa=pump_ml*np*eta_pv/1000，P=2*dp*Q/(60*eta_pv*eta_pm)。工况0平地作业：v=0.963 m/s，mu_r=0.0725，F≈3575.5 N，T≈15.77 N·m，n≈1097.6 r/min；马达51时dp≈2.158 MPa，Q≈60.85 L/min。工况1平地转场：v=1.671 m/s，mu_r=0.0353，F≈1740.9 N，T≈7.68 N·m，n≈1904.9 r/min；马达51时dp≈1.052 MPa，Q≈105.60 L/min。工况2坡地直行：slope=8.5°，v=0.672 m/s，mu_r=0.0796，F≈11171.6 N，T≈49.28 N·m，n≈766.0 r/min；马达51时dp≈6.748 MPa，Q≈42.46 L/min。所选P57_M51：泵57 mL/rev可供Qa=57*2485*0.92/1000≈130.31 L/min，大于各工况最大需求105.60 L/min；马达51各工况dp最大6.748 MPa<28 MPa；马达转速最大1904.9 r/min<3000 r/min；泵转速2485 r/min<3000 r/min；两泵总轴功率最大约11.53 kW<33.47 kW；附着检查F<=adhesion*m*g*cosθ：工况0限值≈22499 N>3575.5 N，工况1限值≈26590 N>1740.9 N，工况2限值≈22252 N>11171.6 N，均满足。按目录排序规则先最小泵排量再最小马达排量，泵45因流量不足被排除，泵57+马达51为满足全部已建模约束的推荐候选。

待核实事项：
- 本模型仅量化直行，不量化转向负载；continuous_radius与counterrotation_pivot转向能力未在本计算中校核。
- 未评价滑移与复杂土壤机理、制动、动态、热平衡、结构强度寿命、实物安装干涉、采购可得性、作业喂入耦合。
- 未计双功率流内部循环功率损失与零速泄漏；本方案为独立HST，不适用该项。
- 所有计算为手算推导，未经外部工程计算器或代码执行器校核。
- 未支持下坡制动、倒行/再生工况。

采用的完整输入见 final_design.json；独立评分未回传模型。
